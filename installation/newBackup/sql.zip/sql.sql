/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `nourpharm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `nourpharm`;

CREATE TABLE IF NOT EXISTS `addon_settings` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `test_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `settings_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'live',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  KEY `payment_settings_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `addon_settings` (`id`, `key_name`, `live_values`, `test_values`, `settings_type`, `mode`, `is_active`, `created_at`, `updated_at`, `additional_data`) VALUES
	('070c6bbd-d777-11ed-96f4-0c7a158e4469', 'twilio', '{"gateway":"twilio","mode":"live","status":"0","sid":"data","messaging_service_sid":"data","token":"data","from":"data","otp_template":"data"}', '{"gateway":"twilio","mode":"live","status":"0","sid":"data","messaging_service_sid":"data","token":"data","from":"data","otp_template":"data"}', 'sms_config', 'live', 0, NULL, '2023-08-12 07:01:29', NULL),
	('070c766c-d777-11ed-96f4-0c7a158e4469', '2factor', '{"gateway":"2factor","mode":"live","status":"0","api_key":"data"}', '{"gateway":"2factor","mode":"live","status":"0","api_key":"data"}', 'sms_config', 'live', 0, NULL, '2023-08-12 07:01:36', NULL),
	('0d8a9308-d6a5-11ed-962c-0c7a158e4469', 'mercadopago', '{"gateway":"mercadopago","mode":"live","status":0,"access_token":"","public_key":""}', '{"gateway":"mercadopago","mode":"live","status":0,"access_token":"","public_key":""}', 'payment_config', 'test', 0, NULL, '2023-08-27 11:57:11', '{"gateway_title":"Mercadopago","gateway_image":null}'),
	('0d8a9e49-d6a5-11ed-962c-0c7a158e4469', 'liqpay', '{"gateway":"liqpay","mode":"live","status":0,"private_key":"","public_key":""}', '{"gateway":"liqpay","mode":"live","status":0,"private_key":"","public_key":""}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:32:31', '{"gateway_title":"Liqpay","gateway_image":null}'),
	('101befdf-d44b-11ed-8564-0c7a158e4469', 'paypal', '{"gateway":"paypal","mode":"live","status":"0","client_id":"","client_secret":""}', '{"gateway":"paypal","mode":"live","status":"0","client_id":"","client_secret":""}', 'payment_config', 'test', 0, NULL, '2023-08-30 03:41:32', '{"gateway_title":"Paypal","gateway_image":null}'),
	('133d9647-cabb-11ed-8fec-0c7a158e4469', 'hyper_pay', '{"gateway":"hyper_pay","mode":"test","status":"0","entity_id":"data","access_code":"data"}', '{"gateway":"hyper_pay","mode":"test","status":"0","entity_id":"data","access_code":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:32:42', '{"gateway_title":null,"gateway_image":""}'),
	('1821029f-d776-11ed-96f4-0c7a158e4469', 'msg91', '{"gateway":"msg91","mode":"live","status":"0","template_id":"data","auth_key":"data"}', '{"gateway":"msg91","mode":"live","status":"0","template_id":"data","auth_key":"data"}', 'sms_config', 'live', 0, NULL, '2023-08-12 07:01:48', NULL),
	('18210f2b-d776-11ed-96f4-0c7a158e4469', 'nexmo', '{"gateway":"nexmo","mode":"live","status":"0","api_key":"","api_secret":"","token":"","from":"","otp_template":""}', '{"gateway":"nexmo","mode":"live","status":"0","api_key":"","api_secret":"","token":"","from":"","otp_template":""}', 'sms_config', 'live', 0, NULL, '2023-04-10 02:14:44', NULL),
	('18fbb21f-d6ad-11ed-962c-0c7a158e4469', 'foloosi', '{"gateway":"foloosi","mode":"test","status":"0","merchant_key":"data"}', '{"gateway":"foloosi","mode":"test","status":"0","merchant_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:34:33', '{"gateway_title":null,"gateway_image":""}'),
	('2767d142-d6a1-11ed-962c-0c7a158e4469', 'paytm', '{"gateway":"paytm","mode":"live","status":0,"merchant_key":"","merchant_id":"","merchant_website_link":""}', '{"gateway":"paytm","mode":"live","status":0,"merchant_key":"","merchant_id":"","merchant_website_link":""}', 'payment_config', 'test', 0, NULL, '2023-08-22 06:30:55', '{"gateway_title":"Paytm","gateway_image":null}'),
	('3201d2e6-c937-11ed-a424-0c7a158e4469', 'amazon_pay', '{"gateway":"amazon_pay","mode":"test","status":"0","pass_phrase":"data","access_code":"data","merchant_identifier":"data"}', '{"gateway":"amazon_pay","mode":"test","status":"0","pass_phrase":"data","access_code":"data","merchant_identifier":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:36:07', '{"gateway_title":null,"gateway_image":""}'),
	('4593b25c-d6a1-11ed-962c-0c7a158e4469', 'paytabs', '{"gateway":"paytabs","mode":"live","status":0,"profile_id":"","server_key":"","base_url":"https:\\/\\/secure-egypt.paytabs.com\\/"}', '{"gateway":"paytabs","mode":"live","status":0,"profile_id":"","server_key":"","base_url":"https:\\/\\/secure-egypt.paytabs.com\\/"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:34:51', '{"gateway_title":"Paytabs","gateway_image":null}'),
	('4e9b8dfb-e7d1-11ed-a559-0c7a158e4469', 'bkash', '{"gateway":"bkash","mode":"live","status":"0","app_key":"","app_secret":"","username":"","password":""}', '{"gateway":"bkash","mode":"live","status":"0","app_key":"","app_secret":"","username":"","password":""}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:39:42', '{"gateway_title":"Bkash","gateway_image":null}'),
	('544a24a4-c872-11ed-ac7a-0c7a158e4469', 'fatoorah', '{"gateway":"fatoorah","mode":"test","status":"0","api_key":"data"}', '{"gateway":"fatoorah","mode":"test","status":"0","api_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:36:24', '{"gateway_title":null,"gateway_image":""}'),
	('58c1bc8a-d6ac-11ed-962c-0c7a158e4469', 'ccavenue', '{"gateway":"ccavenue","mode":"test","status":"0","merchant_id":"data","working_key":"data","access_code":"data"}', '{"gateway":"ccavenue","mode":"test","status":"0","merchant_id":"data","working_key":"data","access_code":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 03:42:38', '{"gateway_title":null,"gateway_image":"2023-04-13-643783f01d386.png"}'),
	('5e2d2ef9-d6ab-11ed-962c-0c7a158e4469', 'thawani', '{"gateway":"thawani","mode":"test","status":"0","public_key":"data","private_key":"data"}', '{"gateway":"thawani","mode":"test","status":"0","public_key":"data","private_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:50:40', '{"gateway_title":null,"gateway_image":"2023-04-13-64378f9856f29.png"}'),
	('60cc83cc-d5b9-11ed-b56f-0c7a158e4469', 'sixcash', '{"gateway":"sixcash","mode":"test","status":"0","public_key":"data","secret_key":"data","merchant_number":"data","base_url":"data"}', '{"gateway":"sixcash","mode":"test","status":"0","public_key":"data","secret_key":"data","merchant_number":"data","base_url":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:16:17', '{"gateway_title":null,"gateway_image":"2023-04-12-6436774e77ff9.png"}'),
	('68579846-d8e8-11ed-8249-0c7a158e4469', 'alphanet_sms', '{"gateway":"alphanet_sms","mode":"live","status":0,"api_key":"","otp_template":""}', '{"gateway":"alphanet_sms","mode":"live","status":0,"api_key":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('6857a2e8-d8e8-11ed-8249-0c7a158e4469', 'sms_to', '{"gateway":"sms_to","mode":"live","status":0,"api_key":"","sender_id":"","otp_template":""}', '{"gateway":"sms_to","mode":"live","status":0,"api_key":"","sender_id":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('74c30c00-d6a6-11ed-962c-0c7a158e4469', 'hubtel', '{"gateway":"hubtel","mode":"test","status":"0","account_number":"data","api_id":"data","api_key":"data"}', '{"gateway":"hubtel","mode":"test","status":"0","account_number":"data","api_id":"data","api_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:37:43', '{"gateway_title":null,"gateway_image":""}'),
	('74e46b0a-d6aa-11ed-962c-0c7a158e4469', 'tap', '{"gateway":"tap","mode":"test","status":"0","secret_key":"data"}', '{"gateway":"tap","mode":"test","status":"0","secret_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:50:09', '{"gateway_title":null,"gateway_image":""}'),
	('761ca96c-d1eb-11ed-87ca-0c7a158e4469', 'swish', '{"gateway":"swish","mode":"test","status":"0","number":"data"}', '{"gateway":"swish","mode":"test","status":"0","number":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:17:02', '{"gateway_title":null,"gateway_image":""}'),
	('7b1c3c5f-d2bd-11ed-b485-0c7a158e4469', 'payfast', '{"gateway":"payfast","mode":"test","status":"0","merchant_id":"data","secured_key":"data"}', '{"gateway":"payfast","mode":"test","status":"0","merchant_id":"data","secured_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:18:13', '{"gateway_title":null,"gateway_image":""}'),
	('8592417b-d1d1-11ed-a984-0c7a158e4469', 'esewa', '{"gateway":"esewa","mode":"test","status":"0","merchantCode":"data"}', '{"gateway":"esewa","mode":"test","status":"0","merchantCode":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:17:38', '{"gateway_title":null,"gateway_image":""}'),
	('9162a1dc-cdf1-11ed-affe-0c7a158e4469', 'viva_wallet', '{"gateway":"viva_wallet","mode":"test","status":"0","client_id": "","client_secret": "", "source_code":""}\n', '{"gateway":"viva_wallet","mode":"test","status":"0","client_id": "","client_secret": "", "source_code":""}\n', 'payment_config', 'test', 0, NULL, NULL, NULL),
	('998ccc62-d6a0-11ed-962c-0c7a158e4469', 'stripe', '{"gateway":"stripe","mode":"live","status":"0","api_key":null,"published_key":null}', '{"gateway":"stripe","mode":"live","status":"0","api_key":null,"published_key":null}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:18:55', '{"gateway_title":"Stripe","gateway_image":null}'),
	('a3313755-c95d-11ed-b1db-0c7a158e4469', 'iyzi_pay', '{"gateway":"iyzi_pay","mode":"test","status":"0","api_key":"data","secret_key":"data","base_url":"data"}', '{"gateway":"iyzi_pay","mode":"test","status":"0","api_key":"data","secret_key":"data","base_url":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:20:02', '{"gateway_title":null,"gateway_image":""}'),
	('a76c8993-d299-11ed-b485-0c7a158e4469', 'momo', '{"gateway":"momo","mode":"live","status":"0","api_key":"data","api_user":"data","subscription_key":"data"}', '{"gateway":"momo","mode":"live","status":"0","api_key":"data","api_user":"data","subscription_key":"data"}', 'payment_config', 'live', 0, NULL, '2023-08-30 04:19:28', '{"gateway_title":null,"gateway_image":""}'),
	('a8608119-cc76-11ed-9bca-0c7a158e4469', 'moncash', '{"gateway":"moncash","mode":"test","status":"0","client_id":"data","secret_key":"data"}', '{"gateway":"moncash","mode":"test","status":"0","client_id":"data","secret_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:47:34', '{"gateway_title":null,"gateway_image":""}'),
	('ad5af1c1-d6a2-11ed-962c-0c7a158e4469', 'razor_pay', '{"gateway":"razor_pay","mode":"live","status":"0","api_key":null,"api_secret":null}', '{"gateway":"razor_pay","mode":"live","status":"0","api_key":null,"api_secret":null}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:47:00', '{"gateway_title":"Razor pay","gateway_image":null}'),
	('ad5b02a0-d6a2-11ed-962c-0c7a158e4469', 'senang_pay', '{"gateway":"senang_pay","mode":"live","status":"0","callback_url":null,"secret_key":null,"merchant_id":null}', '{"gateway":"senang_pay","mode":"live","status":"0","callback_url":null,"secret_key":null,"merchant_id":null}', 'payment_config', 'test', 0, NULL, '2023-08-27 09:58:57', '{"gateway_title":"Senang pay","gateway_image":null}'),
	('b6c333f6-d8e9-11ed-8249-0c7a158e4469', 'akandit_sms', '{"gateway":"akandit_sms","mode":"live","status":0,"username":"","password":"","otp_template":""}', '{"gateway":"akandit_sms","mode":"live","status":0,"username":"","password":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('b6c33c87-d8e9-11ed-8249-0c7a158e4469', 'global_sms', '{"gateway":"global_sms","mode":"live","status":0,"user_name":"","password":"","from":"","otp_template":""}', '{"gateway":"global_sms","mode":"live","status":0,"user_name":"","password":"","from":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('b8992bd4-d6a0-11ed-962c-0c7a158e4469', 'paymob_accept', '{"gateway":"paymob_accept","mode":"live","status":"0","callback_url":null,"api_key":"","iframe_id":"","integration_id":"","hmac":""}', '{"gateway":"paymob_accept","mode":"live","status":"0","callback_url":null,"api_key":"","iframe_id":"","integration_id":"","hmac":""}', 'payment_config', 'test', 0, NULL, NULL, '{"gateway_title":"Paymob accept","gateway_image":null}'),
	('c41c0dcd-d119-11ed-9f67-0c7a158e4469', 'maxicash', '{"gateway":"maxicash","mode":"test","status":"0","merchantId":"data","merchantPassword":"data"}', '{"gateway":"maxicash","mode":"test","status":"0","merchantId":"data","merchantPassword":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:49:15', '{"gateway_title":null,"gateway_image":""}'),
	('c9249d17-cd60-11ed-b879-0c7a158e4469', 'pvit', '{"gateway":"pvit","mode":"test","status":"0","mc_tel_merchant": "","access_token": "", "mc_merchant_code": ""}', '{"gateway":"pvit","mode":"test","status":"0","mc_tel_merchant": "","access_token": "", "mc_merchant_code": ""}', 'payment_config', 'test', 0, NULL, NULL, NULL),
	('cb0081ce-d775-11ed-96f4-0c7a158e4469', 'releans', '{"gateway":"releans","mode":"live","status":0,"api_key":"","from":"","otp_template":""}', '{"gateway":"releans","mode":"live","status":0,"api_key":"","from":"","otp_template":""}', 'sms_config', 'live', 0, NULL, '2023-04-10 02:14:44', NULL),
	('d4f3f5f1-d6a0-11ed-962c-0c7a158e4469', 'flutterwave', '{"gateway":"flutterwave","mode":"live","status":0,"secret_key":"","public_key":"","hash":""}', '{"gateway":"flutterwave","mode":"live","status":0,"secret_key":"","public_key":"","hash":""}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:41:03', '{"gateway_title":"Flutterwave","gateway_image":null}'),
	('d822f1a5-c864-11ed-ac7a-0c7a158e4469', 'paystack', '{"gateway":"paystack","mode":"live","status":"0","callback_url":"https:\\/\\/api.paystack.co","public_key":null,"secret_key":null,"merchant_email":null}', '{"gateway":"paystack","mode":"live","status":"0","callback_url":"https:\\/\\/api.paystack.co","public_key":null,"secret_key":null,"merchant_email":null}', 'payment_config', 'test', 0, NULL, '2023-08-30 04:20:45', '{"gateway_title":"Paystack","gateway_image":null}'),
	('daec8d59-c893-11ed-ac7a-0c7a158e4469', 'xendit', '{"gateway":"xendit","mode":"test","status":"0","api_key":"data"}', '{"gateway":"xendit","mode":"test","status":"0","api_key":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:35:46', '{"gateway_title":null,"gateway_image":""}'),
	('dc0f5fc9-d6a5-11ed-962c-0c7a158e4469', 'worldpay', '{"gateway":"worldpay","mode":"test","status":"0","OrgUnitId":"data","jwt_issuer":"data","mac":"data","merchantCode":"data","xml_password":"data"}', '{"gateway":"worldpay","mode":"test","status":"0","OrgUnitId":"data","jwt_issuer":"data","mac":"data","merchantCode":"data","xml_password":"data"}', 'payment_config', 'test', 0, NULL, '2023-08-12 06:35:26', '{"gateway_title":null,"gateway_image":""}'),
	('e0450278-d8eb-11ed-8249-0c7a158e4469', 'signal_wire', '{"gateway":"signal_wire","mode":"live","status":0,"project_id":"","token":"","space_url":"","from":"","otp_template":""}', '{"gateway":"signal_wire","mode":"live","status":0,"project_id":"","token":"","space_url":"","from":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('e0450b40-d8eb-11ed-8249-0c7a158e4469', 'paradox', '{"gateway":"paradox","mode":"live","status":"0","api_key":"","sender_id":""}', '{"gateway":"paradox","mode":"live","status":"0","api_key":"","sender_id":""}', 'sms_config', 'live', 0, NULL, '2023-09-10 01:14:01', NULL),
	('ea346efe-cdda-11ed-affe-0c7a158e4469', 'ssl_commerz', '{"gateway":"ssl_commerz","mode":"live","status":"0","store_id":"","store_password":""}', '{"gateway":"ssl_commerz","mode":"live","status":"0","store_id":"","store_password":""}', 'payment_config', 'test', 0, NULL, '2023-08-30 03:43:49', '{"gateway_title":"Ssl commerz","gateway_image":null}'),
	('eed88336-d8ec-11ed-8249-0c7a158e4469', 'hubtel', '{"gateway":"hubtel","mode":"live","status":0,"sender_id":"","client_id":"","client_secret":"","otp_template":""}', '{"gateway":"hubtel","mode":"live","status":0,"sender_id":"","client_id":"","client_secret":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('f149c546-d8ea-11ed-8249-0c7a158e4469', 'viatech', '{"gateway":"viatech","mode":"live","status":0,"api_url":"","api_key":"","sender_id":"","otp_template":""}', '{"gateway":"viatech","mode":"live","status":0,"api_url":"","api_key":"","sender_id":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL),
	('f149cd9c-d8ea-11ed-8249-0c7a158e4469', '019_sms', '{"gateway":"019_sms","mode":"live","status":0,"password":"","username":"","username_for_token":"","sender":"","otp_template":""}', '{"gateway":"019_sms","mode":"live","status":0,"password":"","username":"","username_for_token":"","sender":"","otp_template":""}', 'sms_config', 'live', 0, NULL, NULL, NULL);

CREATE TABLE IF NOT EXISTS `add_fund_bonus_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bonus_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bonus_amount` double(14,2) NOT NULL DEFAULT '0.00',
  `min_add_money_amount` double(14,2) NOT NULL DEFAULT '0.00',
  `max_bonus_amount` double(14,2) NOT NULL DEFAULT '0.00',
  `start_date_time` datetime DEFAULT NULL,
  `end_date_time` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `admins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_role_id` bigint NOT NULL DEFAULT '2',
  `image` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def.png',
  `identify_image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `identify_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identify_number` int DEFAULT NULL,
  `email` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `admins` (`id`, `name`, `phone`, `admin_role_id`, `image`, `identify_image`, `identify_type`, `identify_number`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `status`) VALUES
	(1, 'ahmed emam', '01143049200', 1, 'def.png', NULL, NULL, NULL, 'ahmedelziaty94@gmail.com', NULL, '$2y$10$YvLo6Q1JL7FGmMFVuNnHsemGzlKXYu0EvPHYbVXFt4rRACU2kkTfe', '2VOqkDxSYnfD44utPfnePUGkf7hZv7oP6vUuuApjbU71RZfPCvd9l40X8DF4', '2024-07-07 11:00:25', '2024-07-07 11:00:25', 1);

CREATE TABLE IF NOT EXISTS `admin_roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module_access` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `admin_roles` (`id`, `name`, `module_access`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'Master Admin', NULL, 1, NULL, NULL);

CREATE TABLE IF NOT EXISTS `admin_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint DEFAULT NULL,
  `inhouse_earning` double NOT NULL DEFAULT '0',
  `withdrawn` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `commission_earned` double(8,2) NOT NULL DEFAULT '0.00',
  `delivery_charge_earned` double(8,2) NOT NULL DEFAULT '0.00',
  `pending_amount` double(8,2) NOT NULL DEFAULT '0.00',
  `total_tax_collected` double(8,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `admin_wallets` (`id`, `admin_id`, `inhouse_earning`, `withdrawn`, `created_at`, `updated_at`, `commission_earned`, `delivery_charge_earned`, `pending_amount`, `total_tax_collected`) VALUES
	(1, 1, 0, 0, NULL, NULL, 0.00, 0.00, 0.00, 0.00);

CREATE TABLE IF NOT EXISTS `admin_wallet_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `payment` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `attributes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `banners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `published` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_id` bigint DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_text` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_color` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `billing_addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned DEFAULT NULL,
  `contact_person_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def.png',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `brands` (`id`, `name`, `image`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'fffffff', '2024-07-14-669388d100909.webp', 1, '2024-07-14 11:14:09', '2024-07-14 11:14:09');

CREATE TABLE IF NOT EXISTS `business_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `business_settings` (`id`, `type`, `value`, `created_at`, `updated_at`) VALUES
	(1, 'system_default_currency', '1', '2020-10-11 07:43:44', '2021-06-04 18:25:29'),
	(2, 'language', '[{"id":"1","name":"english","code":"en","status":1,"default":true}]', '2020-10-11 07:53:02', '2023-10-13 11:34:53'),
	(3, 'mail_config', '{"status":0,"name":"demo","host":"mail.demo.com","driver":"SMTP","port":"587","username":"info@demo.com","email_id":"info@demo.com","encryption":"TLS","password":"demo"}', '2020-10-12 10:29:18', '2021-07-06 12:32:01'),
	(4, 'cash_on_delivery', '{"status":"1"}', NULL, '2021-05-25 21:21:15'),
	(6, 'ssl_commerz_payment', '{"status":"0","environment":"sandbox","store_id":"","store_password":""}', '2020-11-09 08:36:51', '2023-01-10 05:51:56'),
	(10, 'company_phone', '000000000', NULL, '2020-12-08 14:15:01'),
	(11, 'company_name', '', NULL, '2021-02-27 18:11:53'),
	(12, 'company_web_logo', '2021-05-25-60ad1b313a9d4.png', NULL, '2021-05-25 21:43:45'),
	(13, 'company_mobile_logo', '2021-02-20-6030c88c91911.png', NULL, '2021-02-20 14:30:04'),
	(14, 'terms_condition', '<p>terms and conditions</p>', NULL, '2021-06-11 01:51:36'),
	(15, 'about_us', '<p>this is about us page. hello and hi from about page description..</p>', NULL, '2021-06-11 01:42:53'),
	(16, 'sms_nexmo', '{"status":"0","nexmo_key":"custo5cc042f7abf4c","nexmo_secret":"custo5cc042f7abf4c@ssl"}', NULL, NULL),
	(17, 'company_email', 'Copy@6amtech.com', NULL, '2021-03-15 12:29:51'),
	(18, 'colors', '{"primary":"#1b7fed","secondary":"black","primary_light":"#CFDFFB"}', '2020-10-11 13:53:02', '2024-03-27 03:12:32'),
	(19, 'company_footer_logo', '2021-02-20-6030c8a02a5f9.png', NULL, '2021-02-20 14:30:24'),
	(20, 'company_copyright_text', 'CopyRight 6amTech@2021', NULL, '2021-03-15 12:30:47'),
	(21, 'download_app_apple_stroe', '{"status":"1","link":"https:\\/\\/www.target.com\\/s\\/apple+store++now?ref=tgt_adv_XS000000&AFID=msn&fndsrc=tgtao&DFA=71700000012505188&CPNG=Electronics_Portable+Computers&adgroup=Portable+Computers&LID=700000001176246&LNM=apple+store+near+me+now&MT=b&network=s&device=c&location=12&targetid=kwd-81913773633608:loc-12&ds_rl=1246978&ds_rl=1248099&gclsrc=ds"}', NULL, '2020-12-08 12:54:53'),
	(22, 'download_app_google_stroe', '{"status":"1","link":"https:\\/\\/play.google.com\\/store?hl=en_US&gl=US"}', NULL, '2020-12-08 12:54:48'),
	(23, 'company_fav_icon', '2021-03-02-603df1634614f.png', '2020-10-11 13:53:02', '2021-03-02 14:03:48'),
	(24, 'fcm_topic', '', NULL, NULL),
	(25, 'fcm_project_id', '', NULL, NULL),
	(26, 'push_notification_key', 'Put your firebase server key here.', NULL, NULL),
	(27, 'order_pending_message', '{"status":"1","message":"order pen message"}', NULL, NULL),
	(28, 'order_confirmation_msg', '{"status":"1","message":"Order con Message"}', NULL, NULL),
	(29, 'order_processing_message', '{"status":"1","message":"Order pro Message"}', NULL, NULL),
	(30, 'out_for_delivery_message', '{"status":"1","message":"Order ouut Message"}', NULL, NULL),
	(31, 'order_delivered_message', '{"status":"1","message":"Order del Message"}', NULL, NULL),
	(33, 'sales_commission', '0', NULL, '2021-06-11 18:13:13'),
	(34, 'seller_registration', '1', NULL, '2021-06-04 21:02:48'),
	(35, 'pnc_language', '["en"]', NULL, NULL),
	(36, 'order_returned_message', '{"status":"1","message":"Order hh Message"}', NULL, NULL),
	(37, 'order_failed_message', '{"status":null,"message":"Order fa Message"}', NULL, NULL),
	(40, 'delivery_boy_assign_message', '{"status":0,"message":""}', NULL, NULL),
	(41, 'delivery_boy_start_message', '{"status":0,"message":""}', NULL, NULL),
	(42, 'delivery_boy_delivered_message', '{"status":0,"message":""}', NULL, NULL),
	(43, 'terms_and_conditions', '', NULL, NULL),
	(44, 'minimum_order_value', '1', NULL, NULL),
	(45, 'privacy_policy', '<p>my privacy policy</p>\r\n\r\n<p>&nbsp;</p>', NULL, '2021-07-06 11:09:07'),
	(48, 'currency_model', 'single_currency', NULL, NULL),
	(49, 'social_login', '[{"login_medium":"google","client_id":"","client_secret":"","status":""},{"login_medium":"facebook","client_id":"","client_secret":"","status":""}]', NULL, NULL),
	(50, 'digital_payment', '{"status":"1"}', NULL, NULL),
	(51, 'phone_verification', '0', NULL, NULL),
	(52, 'email_verification', '0', NULL, NULL),
	(53, 'order_verification', '0', NULL, NULL),
	(54, 'country_code', 'BD', NULL, NULL),
	(55, 'pagination_limit', '10', NULL, NULL),
	(56, 'shipping_method', 'inhouse_shipping', NULL, NULL),
	(59, 'forgot_password_verification', 'email', NULL, NULL),
	(61, 'stock_limit', '10', NULL, '2024-07-15 21:09:17'),
	(64, 'announcement', '{"status":null,"color":null,"text_color":null,"announcement":null}', NULL, NULL),
	(65, 'fawry_pay', '{"status":0,"merchant_code":"","security_key":""}', NULL, '2022-01-18 09:46:30'),
	(66, 'recaptcha', '{"status":0,"site_key":"","secret_key":""}', NULL, '2022-01-18 09:46:30'),
	(67, 'seller_pos', '0', NULL, NULL),
	(70, 'refund_day_limit', '0', NULL, NULL),
	(71, 'business_mode', 'multi', NULL, NULL),
	(72, 'mail_config_sendgrid', '{"status":0,"name":"","host":"","driver":"","port":"","username":"","email_id":"","encryption":"","password":""}', NULL, NULL),
	(73, 'decimal_point_settings', '2', NULL, NULL),
	(74, 'shop_address', '', NULL, NULL),
	(75, 'billing_input_by_customer', '1', NULL, NULL),
	(76, 'wallet_status', '0', NULL, NULL),
	(77, 'loyalty_point_status', '0', NULL, NULL),
	(78, 'wallet_add_refund', '0', NULL, NULL),
	(79, 'loyalty_point_exchange_rate', '0', NULL, NULL),
	(80, 'loyalty_point_item_purchase_point', '0', NULL, NULL),
	(81, 'loyalty_point_minimum_point', '0', NULL, NULL),
	(82, 'minimum_order_limit', '1', NULL, NULL),
	(83, 'product_brand', '1', NULL, '2024-07-15 21:09:17'),
	(84, 'digital_product', '1', NULL, '2024-07-15 21:09:17'),
	(85, 'delivery_boy_expected_delivery_date_message', '{"status":0,"message":""}', NULL, NULL),
	(86, 'order_canceled', '{"status":0,"message":""}', NULL, NULL),
	(87, 'refund-policy', '{"status":1,"content":""}', NULL, '2023-03-04 06:25:36'),
	(88, 'return-policy', '{"status":1,"content":""}', NULL, '2023-03-04 06:25:36'),
	(89, 'cancellation-policy', '{"status":1,"content":""}', NULL, '2023-03-04 06:25:36'),
	(90, 'offline_payment', '{"status":0}', NULL, '2023-03-04 06:25:36'),
	(91, 'temporary_close', '{"status":0}', NULL, '2023-03-04 06:25:36'),
	(92, 'vacation_add', '{"status":0,"vacation_start_date":null,"vacation_end_date":null,"vacation_note":null}', NULL, '2023-03-04 06:25:36'),
	(93, 'cookie_setting', '{"status":0,"cookie_text":null}', NULL, '2023-03-04 06:25:36'),
	(94, 'maximum_otp_hit', '0', NULL, '2023-06-13 13:04:49'),
	(95, 'otp_resend_time', '0', NULL, '2023-06-13 13:04:49'),
	(96, 'temporary_block_time', '0', NULL, '2023-06-13 13:04:49'),
	(97, 'maximum_login_hit', '0', NULL, '2023-06-13 13:04:49'),
	(98, 'temporary_login_block_time', '0', NULL, '2023-06-13 13:04:49'),
	(104, 'apple_login', '[{"login_medium":"apple","client_id":"","client_secret":"","status":0,"team_id":"","key_id":"","service_file":"","redirect_url":""}]', NULL, '2023-10-13 05:34:53'),
	(105, 'ref_earning_status', '0', NULL, '2023-10-13 05:34:53'),
	(106, 'ref_earning_exchange_rate', '0', NULL, '2023-10-13 05:34:53'),
	(107, 'guest_checkout', '0', NULL, '2023-10-13 11:34:53'),
	(108, 'minimum_order_amount', '0', NULL, '2023-10-13 11:34:53'),
	(109, 'minimum_order_amount_by_seller', '0', NULL, '2023-10-13 11:34:53'),
	(110, 'minimum_order_amount_status', '0', NULL, '2023-10-13 11:34:53'),
	(111, 'admin_login_url', 'admin', NULL, '2023-10-13 11:34:53'),
	(112, 'employee_login_url', 'employee', NULL, '2023-10-13 11:34:53'),
	(113, 'free_delivery_status', '0', NULL, '2023-10-13 11:34:53'),
	(114, 'free_delivery_responsibility', 'admin', NULL, '2023-10-13 11:34:53'),
	(115, 'free_delivery_over_amount', '0', NULL, '2023-10-13 11:34:53'),
	(116, 'free_delivery_over_amount_seller', '0', NULL, '2023-10-13 11:34:53'),
	(117, 'add_funds_to_wallet', '0', NULL, '2023-10-13 11:34:53'),
	(118, 'minimum_add_fund_amount', '0', NULL, '2023-10-13 11:34:53'),
	(119, 'maximum_add_fund_amount', '0', NULL, '2023-10-13 11:34:53'),
	(120, 'user_app_version_control', '{"for_android":{"status":1,"version":"14.1","link":""},"for_ios":{"status":1,"version":"14.1","link":""}}', NULL, '2023-10-13 11:34:53'),
	(121, 'seller_app_version_control', '{"for_android":{"status":1,"version":"14.1","link":""},"for_ios":{"status":1,"version":"14.1","link":""}}', NULL, '2023-10-13 11:34:53'),
	(122, 'delivery_man_app_version_control', '{"for_android":{"status":1,"version":"14.1","link":""},"for_ios":{"status":1,"version":"14.1","link":""}}', NULL, '2023-10-13 11:34:53'),
	(123, 'whatsapp', '{"status":1,"phone":"00000000000"}', NULL, '2023-10-13 11:34:53'),
	(124, 'currency_symbol_position', 'left', NULL, '2023-10-13 11:34:53'),
	(148, 'company_reliability', '[{"item":"delivery_info","title":"Fast Delivery all across the country","image":"","status":1},{"item":"safe_payment","title":"Safe Payment","image":"","status":1},{"item":"return_policy","title":"7 Days Return Policy","image":"","status":1},{"item":"authentic_product","title":"100% Authentic Products","image":"","status":1}]', NULL, NULL),
	(149, 'react_setup', '{"status":0,"react_license_code":"","react_domain":"","react_platform":""}', NULL, '2024-01-09 04:05:15'),
	(150, 'app_activation', '{"software_id":"","is_active":0}', NULL, '2024-01-09 04:05:15'),
	(151, 'shop_banner', '', NULL, '2023-10-13 11:34:53'),
	(152, 'map_api_status', '1', NULL, '2024-03-27 03:12:32'),
	(177, 'market_deficiencies', '{"status":"1","available_percentage":"3.5","available_quantity":"7","parent_items":"2","deficiencies_items":"3"}', NULL, '2024-07-15 21:09:17');

CREATE TABLE IF NOT EXISTS `carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint DEFAULT NULL,
  `cart_group_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `product_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'physical',
  `digital_product_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `choices` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `variations` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `variant` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quantity` int NOT NULL DEFAULT '1',
  `price` double NOT NULL DEFAULT '1',
  `tax` double NOT NULL DEFAULT '1',
  `discount` double NOT NULL DEFAULT '1',
  `tax_model` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'exclude',
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_id` bigint DEFAULT NULL,
  `seller_is` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shop_info` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_cost` double(8,2) DEFAULT NULL,
  `shipping_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_guest` tinyint NOT NULL DEFAULT '0',
  `is_checked` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `carts` (`id`, `customer_id`, `cart_group_id`, `product_id`, `product_type`, `digital_product_type`, `color`, `choices`, `variations`, `variant`, `quantity`, `price`, `tax`, `discount`, `tax_model`, `slug`, `name`, `thumbnail`, `seller_id`, `seller_is`, `created_at`, `updated_at`, `shop_info`, `shipping_cost`, `shipping_type`, `is_guest`, `is_checked`) VALUES
	(18, 28, 'guest-5wpxs-1721038554', 2, 'physical', NULL, NULL, '[]', '[]', '', 4, 80, 0, 0, 'include', 'yyyyyyyyy-eLzAKG', 'qqqqqqqqqqq', '2024-07-14-669389509a060.webp', 1, 'admin', '2024-07-15 13:15:54', '2024-07-15 13:15:54', '', 0.00, 'product_wise', 1, 0),
	(19, 29, 'guest-TT14M-1720989922', 2, 'physical', NULL, NULL, '[]', '[]', '', 1, 80, 0, 0, 'include', 'yyyyyyyyy-eLzAKG', 'dsdgvgre', '2024-07-14-669389509a060.webp', 1, 'admin', '2024-07-14 23:45:22', '2024-07-14 23:45:22', '', 0.00, 'product_wise', 1, 0),
	(22, 32, 'guest-EZCHo-1721066769', 4, 'physical', NULL, NULL, '[]', '[]', '', 2, 80, 0, 0, 'include', 'yjliooyyyyy-eLzAKG', 'ccccccc', '2024-07-14-669389509a060.webp', 1, 'admin', '2024-07-15 21:06:09', '2024-07-15 21:06:09', '', 0.00, 'product_wise', 1, 0),
	(23, 32, 'guest-EZCHo-1721066769', 8, 'physical', NULL, NULL, '[]', '[]', '', 2, 80, 0, 0, 'include', 'ioxdseLzAKG', 'hhhhhhhhh', '2024-07-14-669389509a060.webp', 1, 'admin', '2024-07-15 21:06:28', '2024-07-15 21:06:28', '', 0.00, 'product_wise', 1, 0);

CREATE TABLE IF NOT EXISTS `cart_shippings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_group_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_method_id` bigint DEFAULT NULL,
  `shipping_cost` double(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int NOT NULL,
  `position` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `home_status` tinyint(1) NOT NULL DEFAULT '0',
  `priority` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `categories` (`id`, `name`, `slug`, `icon`, `parent_id`, `position`, `created_at`, `updated_at`, `home_status`, `priority`) VALUES
	(1, 'pharmaceutical', 'pharmaceutical', '2024-07-07-6689e13ea9d94.webp', 0, 0, '2024-07-07 08:28:46', '2024-07-07 08:49:07', 1, 0),
	(2, 'All medicines', 'all-medicines', 'def.png', 1, 1, '2024-07-07 08:29:23', '2024-07-07 08:29:23', 0, 0),
	(3, 'Market shortcomings', 'market-shortcomings', 'def.png', 1, 1, '2024-07-07 08:29:49', '2024-07-07 08:29:49', 0, 1),
	(4, 'Drug Offers', 'drug-offers', 'def.png', 1, 1, '2024-07-07 08:35:54', '2024-07-07 08:35:54', 0, 2),
	(5, 'New in the market', 'new-in-the-market', 'def.png', 1, 1, '2024-07-07 08:36:16', '2024-07-07 08:36:16', 0, 3),
	(6, 'makeup', 'makeup', '2024-07-07-6689e33f06063.webp', 0, 0, '2024-07-07 08:37:19', '2024-07-07 08:49:09', 1, 1),
	(7, 'makeup', 'makeup', 'def.png', 6, 1, '2024-07-07 08:37:37', '2024-07-07 08:37:37', 0, 0),
	(8, 'Companies', 'companies', 'def.png', 6, 1, '2024-07-07 08:37:50', '2024-07-07 08:37:50', 0, 1),
	(9, 'New in the market', 'new-in-the-market', 'def.png', 6, 1, '2024-07-07 08:38:53', '2024-07-07 08:38:53', 0, 1),
	(10, 'Children\'s papers', 'childrens-papers', 'def.png', 6, 1, '2024-07-07 08:39:21', '2024-07-07 08:39:21', 0, 2),
	(11, 'Women\'s papers', 'womens-papers', 'def.png', 6, 1, '2024-07-07 08:39:37', '2024-07-07 08:39:37', 0, 3),
	(12, 'Medical Supplies', 'medical-supplies', '2024-07-07-6689e405781b5.webp', 0, 0, '2024-07-07 08:40:37', '2024-07-07 08:49:11', 1, 2);

CREATE TABLE IF NOT EXISTS `category_shipping_costs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint unsigned DEFAULT NULL,
  `category_id` int unsigned DEFAULT NULL,
  `cost` double(8,2) DEFAULT NULL,
  `multiply_qty` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `chattings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `seller_id` bigint DEFAULT NULL,
  `admin_id` bigint DEFAULT NULL,
  `delivery_man_id` bigint DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachment` json DEFAULT NULL,
  `sent_by_customer` tinyint(1) NOT NULL DEFAULT '0',
  `sent_by_seller` tinyint(1) NOT NULL DEFAULT '0',
  `sent_by_admin` tinyint(1) DEFAULT NULL,
  `sent_by_delivery_man` tinyint(1) DEFAULT NULL,
  `seen_by_customer` tinyint(1) NOT NULL DEFAULT '1',
  `seen_by_seller` tinyint(1) NOT NULL DEFAULT '1',
  `seen_by_admin` tinyint(1) DEFAULT NULL,
  `seen_by_delivery_man` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `notification_receiver` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'admin, seller, customer, deliveryman',
  `seen_notification` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shop_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `colors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `code` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

REPLACE INTO `colors` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
	(1, 'IndianRed', '#CD5C5C', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(2, 'LightCoral', '#F08080', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(3, 'Salmon', '#FA8072', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(4, 'DarkSalmon', '#E9967A', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(5, 'LightSalmon', '#FFA07A', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(6, 'Crimson', '#DC143C', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(7, 'Red', '#FF0000', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(8, 'FireBrick', '#B22222', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(9, 'DarkRed', '#8B0000', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(10, 'Pink', '#FFC0CB', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(11, 'LightPink', '#FFB6C1', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(12, 'HotPink', '#FF69B4', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(13, 'DeepPink', '#FF1493', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(14, 'MediumVioletRed', '#C71585', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(15, 'PaleVioletRed', '#DB7093', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(17, 'Coral', '#FF7F50', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(18, 'Tomato', '#FF6347', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(19, 'OrangeRed', '#FF4500', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(20, 'DarkOrange', '#FF8C00', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(21, 'Orange', '#FFA500', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(22, 'Gold', '#FFD700', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(23, 'Yellow', '#FFFF00', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(24, 'LightYellow', '#FFFFE0', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(25, 'LemonChiffon', '#FFFACD', '2018-11-05 02:12:26', '2018-11-05 02:12:26'),
	(26, 'LightGoldenrodYellow', '#FAFAD2', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(27, 'PapayaWhip', '#FFEFD5', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(28, 'Moccasin', '#FFE4B5', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(29, 'PeachPuff', '#FFDAB9', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(30, 'PaleGoldenrod', '#EEE8AA', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(31, 'Khaki', '#F0E68C', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(32, 'DarkKhaki', '#BDB76B', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(33, 'Lavender', '#E6E6FA', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(34, 'Thistle', '#D8BFD8', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(35, 'Plum', '#DDA0DD', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(36, 'Violet', '#EE82EE', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(37, 'Orchid', '#DA70D6', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(39, 'Magenta', '#FF00FF', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(40, 'MediumOrchid', '#BA55D3', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(41, 'MediumPurple', '#9370DB', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(42, 'Amethyst', '#9966CC', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(43, 'BlueViolet', '#8A2BE2', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(44, 'DarkViolet', '#9400D3', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(45, 'DarkOrchid', '#9932CC', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(46, 'DarkMagenta', '#8B008B', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(47, 'Purple', '#800080', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(48, 'Indigo', '#4B0082', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(49, 'SlateBlue', '#6A5ACD', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(50, 'DarkSlateBlue', '#483D8B', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(51, 'MediumSlateBlue', '#7B68EE', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(52, 'GreenYellow', '#ADFF2F', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(53, 'Chartreuse', '#7FFF00', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(54, 'LawnGreen', '#7CFC00', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(55, 'Lime', '#00FF00', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(56, 'LimeGreen', '#32CD32', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(57, 'PaleGreen', '#98FB98', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(58, 'LightGreen', '#90EE90', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(59, 'MediumSpringGreen', '#00FA9A', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(60, 'SpringGreen', '#00FF7F', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(61, 'MediumSeaGreen', '#3CB371', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(62, 'SeaGreen', '#2E8B57', '2018-11-05 02:12:27', '2018-11-05 02:12:27'),
	(63, 'ForestGreen', '#228B22', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(64, 'Green', '#008000', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(65, 'DarkGreen', '#006400', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(66, 'YellowGreen', '#9ACD32', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(67, 'OliveDrab', '#6B8E23', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(68, 'Olive', '#808000', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(69, 'DarkOliveGreen', '#556B2F', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(70, 'MediumAquamarine', '#66CDAA', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(71, 'DarkSeaGreen', '#8FBC8F', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(72, 'LightSeaGreen', '#20B2AA', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(73, 'DarkCyan', '#008B8B', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(74, 'Teal', '#008080', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(75, 'Aqua', '#00FFFF', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(77, 'LightCyan', '#E0FFFF', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(78, 'PaleTurquoise', '#AFEEEE', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(79, 'Aquamarine', '#7FFFD4', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(80, 'Turquoise', '#40E0D0', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(81, 'MediumTurquoise', '#48D1CC', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(82, 'DarkTurquoise', '#00CED1', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(83, 'CadetBlue', '#5F9EA0', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(84, 'SteelBlue', '#4682B4', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(85, 'LightSteelBlue', '#B0C4DE', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(86, 'PowderBlue', '#B0E0E6', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(87, 'LightBlue', '#ADD8E6', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(88, 'SkyBlue', '#87CEEB', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(89, 'LightSkyBlue', '#87CEFA', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(90, 'DeepSkyBlue', '#00BFFF', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(91, 'DodgerBlue', '#1E90FF', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(92, 'CornflowerBlue', '#6495ED', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(94, 'RoyalBlue', '#4169E1', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(95, 'Blue', '#0000FF', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(96, 'MediumBlue', '#0000CD', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(97, 'DarkBlue', '#00008B', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(98, 'Navy', '#000080', '2018-11-05 02:12:28', '2018-11-05 02:12:28'),
	(99, 'MidnightBlue', '#191970', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(100, 'Cornsilk', '#FFF8DC', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(101, 'BlanchedAlmond', '#FFEBCD', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(102, 'Bisque', '#FFE4C4', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(103, 'NavajoWhite', '#FFDEAD', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(104, 'Wheat', '#F5DEB3', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(105, 'BurlyWood', '#DEB887', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(106, 'Tan', '#D2B48C', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(107, 'RosyBrown', '#BC8F8F', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(108, 'SandyBrown', '#F4A460', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(109, 'Goldenrod', '#DAA520', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(110, 'DarkGoldenrod', '#B8860B', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(111, 'Peru', '#CD853F', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(112, 'Chocolate', '#D2691E', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(113, 'SaddleBrown', '#8B4513', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(114, 'Sienna', '#A0522D', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(115, 'Brown', '#A52A2A', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(116, 'Maroon', '#800000', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(117, 'White', '#FFFFFF', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(118, 'Snow', '#FFFAFA', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(119, 'Honeydew', '#F0FFF0', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(120, 'MintCream', '#F5FFFA', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(121, 'Azure', '#F0FFFF', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(122, 'AliceBlue', '#F0F8FF', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(123, 'GhostWhite', '#F8F8FF', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(124, 'WhiteSmoke', '#F5F5F5', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(125, 'Seashell', '#FFF5EE', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(126, 'Beige', '#F5F5DC', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(127, 'OldLace', '#FDF5E6', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(128, 'FloralWhite', '#FFFAF0', '2018-11-05 02:12:29', '2018-11-05 02:12:29'),
	(129, 'Ivory', '#FFFFF0', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(130, 'AntiqueWhite', '#FAEBD7', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(131, 'Linen', '#FAF0E6', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(132, 'LavenderBlush', '#FFF0F5', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(133, 'MistyRose', '#FFE4E1', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(134, 'Gainsboro', '#DCDCDC', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(135, 'LightGrey', '#D3D3D3', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(136, 'Silver', '#C0C0C0', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(137, 'DarkGray', '#A9A9A9', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(138, 'Gray', '#808080', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(139, 'DimGray', '#696969', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(140, 'LightSlateGray', '#778899', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(141, 'SlateGray', '#708090', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(142, 'DarkSlateGray', '#2F4F4F', '2018-11-05 02:12:30', '2018-11-05 02:12:30'),
	(143, 'Black', '#000000', '2018-11-05 02:12:30', '2018-11-05 02:12:30');

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `feedback` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `reply` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `added_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `coupon_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_bearer` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inhouse',
  `seller_id` bigint DEFAULT NULL COMMENT 'NULL=in-house, 0=all seller',
  `customer_id` bigint DEFAULT NULL COMMENT '0 = all customer',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `min_purchase` decimal(8,2) NOT NULL DEFAULT '0.00',
  `max_discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_type` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `limit` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_rate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `currencies` (`id`, `name`, `symbol`, `code`, `exchange_rate`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'USD', '$', 'USD', '1', 1, NULL, '2021-06-27 13:39:37'),
	(2, 'BDT', '৳', 'BDT', '84', 1, NULL, '2021-07-06 11:52:58'),
	(3, 'Indian Rupi', '₹', 'INR', '60', 1, '2020-10-15 17:23:04', '2021-06-04 18:26:38'),
	(4, 'Euro', '€', 'EUR', '100', 1, '2021-05-25 21:00:23', '2021-06-04 18:25:29'),
	(5, 'YEN', '¥', 'JPY', '110', 1, '2021-06-10 22:08:31', '2021-06-26 14:21:10'),
	(6, 'Ringgit', 'RM', 'MYR', '4.16', 1, '2021-07-03 11:08:33', '2021-07-03 11:10:37'),
	(7, 'Rand', 'R', 'ZAR', '14.26', 1, '2021-07-03 11:12:38', '2021-07-03 11:12:42');

CREATE TABLE IF NOT EXISTS `customer_balances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `balance` decimal(8,2) DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_balances_user_id_foreign` (`user_id`),
  CONSTRAINT `customer_balances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `customer_balances` (`id`, `user_id`, `balance`, `status`, `created_at`, `updated_at`) VALUES
	(1, 2, 0.00, 1, '2024-07-14 17:19:27', '2024-07-15 21:13:35');

CREATE TABLE IF NOT EXISTS `customer_slices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_slices_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `customer_slices` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'Ayanna Parrish', 1, '2024-07-15 02:10:07', '2024-07-15 02:10:07'),
	(2, 'wdw', 1, '2024-07-15 02:10:45', '2024-07-15 02:10:45'),
	(3, 'saa', 1, '2024-07-15 02:12:08', '2024-07-15 02:12:08'),
	(4, 'csdcsd', 1, '2024-07-15 02:12:18', '2024-07-15 02:12:18'),
	(5, 'pinterestrrrrrrrrrr', 1, '2024-07-15 02:14:21', '2024-07-15 02:14:21'),
	(6, 'linkedinsss', 1, '2024-07-15 02:14:41', '2024-07-15 02:14:41'),
	(7, 'pinterestrrrrrrrrrraa', 1, '2024-07-15 02:16:44', '2024-07-15 02:16:44'),
	(8, 'csdcsddd', 1, '2024-07-15 02:16:54', '2024-07-15 02:16:54'),
	(9, 'Ayanna Parrishsss', 1, '2024-07-15 02:17:02', '2024-07-15 02:17:02'),
	(10, 'slide 1', 1, '2024-07-15 13:20:12', '2024-07-15 13:20:12'),
	(11, 'slide 222', 1, '2024-07-15 13:20:20', '2024-07-15 14:59:14'),
	(12, 'slide 3', 1, '2024-07-15 13:20:48', '2024-07-15 13:20:48'),
	(13, 'slide 34', 1, '2024-07-15 14:27:37', '2024-07-15 14:27:37'),
	(14, 'slide 333', 1, '2024-07-15 14:33:42', '2024-07-15 14:59:01');

CREATE TABLE IF NOT EXISTS `customer_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint DEFAULT NULL,
  `balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `royality_points` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `customer_wallet_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint DEFAULT NULL,
  `transaction_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `transaction_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_method` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `deal_of_the_days` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_type` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'amount',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `deliveryman_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_man_id` bigint NOT NULL,
  `order_id` bigint NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `deliveryman_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_man_id` bigint NOT NULL,
  `current_balance` decimal(50,2) NOT NULL DEFAULT '0.00',
  `cash_in_hand` decimal(50,2) NOT NULL DEFAULT '0.00',
  `pending_withdraw` decimal(50,2) NOT NULL DEFAULT '0.00',
  `total_withdraw` decimal(50,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `delivery_country_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `delivery_country_codes` (`id`, `country_code`, `created_at`, `updated_at`) VALUES
	(1, 'EG', '2024-07-07 08:06:11', '2024-07-07 08:06:11');

CREATE TABLE IF NOT EXISTS `delivery_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL,
  `deliveryman_id` bigint DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `longitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `delivery_man_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_man_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `user_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `debit` decimal(50,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(50,2) NOT NULL DEFAULT '0.00',
  `transaction_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `delivery_men` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint DEFAULT NULL,
  `f_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `country_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holder_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_online` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `auth_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6yIRXJRRfp78qJsAoKZZ6TTqhzuNJ3TcdvPBmk6n',
  `fcm_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `delivery_zip_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `zipcode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `delivery_zip_codes` (`id`, `zipcode`, `created_at`, `updated_at`) VALUES
	(1, 'محرم بك', '2024-07-07 08:06:46', '2024-07-07 08:06:46'),
	(2, 'الازاريطه ', '2024-07-07 08:06:46', '2024-07-07 08:06:46'),
	(3, 'الانفوشي', '2024-07-07 08:06:46', '2024-07-07 08:06:46'),
	(4, 'الدخيله', '2024-07-07 08:06:46', '2024-07-07 08:06:46');

CREATE TABLE IF NOT EXISTS `digital_product_otp_verifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_details_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_hit_count` tinyint NOT NULL DEFAULT '0',
  `is_temp_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `temp_block_time` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `template_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_design_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `banner_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright_text` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pages` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `social_media` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `hide_field` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `button_content_status` tinyint NOT NULL DEFAULT '1',
  `product_information_status` tinyint NOT NULL DEFAULT '1',
  `order_information_status` tinyint NOT NULL DEFAULT '1',
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `email_templates_chk_1` CHECK (json_valid(`pages`)),
  CONSTRAINT `email_templates_chk_2` CHECK (json_valid(`social_media`)),
  CONSTRAINT `email_templates_chk_3` CHECK (json_valid(`hide_field`))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `email_templates` (`id`, `template_name`, `user_type`, `template_design_name`, `title`, `body`, `banner_image`, `image`, `logo`, `button_name`, `button_url`, `footer_text`, `copyright_text`, `pages`, `social_media`, `hide_field`, `button_content_status`, `product_information_status`, `order_information_status`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'order-received', 'admin', 'order-received', 'New Order Received', '<p><b>Hi {adminName},</b></p><p>We have sent you this email to notify that you have a new order.You will be able to see your orders after login to your panel.</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["icon","product_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(2, 'order-place', 'customer', 'order-place', 'Order # {orderId} Has Been Placed Successfully!', '<p><b>Hi {userName},</b></p><p>Your order from {shopName} has been placed to know the current status of your order click track order</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["icon","product_information","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(3, 'forgot-password', 'customer', 'forgot-password', 'Change Password Request', '<p><b>Hi {userName},</b></p><p>Please click the link below to change your password.</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(4, 'registration-verification', 'customer', 'registration-verification', 'Registration Verification', '<p><b>Hi {userName},</b></p><p>Your verification code is</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(5, 'registration-from-pos', 'customer', 'registration-from-pos', 'Registration Complete', '<p><b>Hi {userName},</b></p><p>Thank you for joining noura m5 Shop.If you want to become a registered customer then reset your password below by using this email. Then you’ll be able to explore the website and app as a registered customer.</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_url","button_content_status","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(6, 'account-block', 'customer', 'account-block', 'Account Blocked', '<div><b>Hi {userName},</b></div><div><b><br></b></div><div>Your account has been blocked due to suspicious activity by the admin .To resolve this issue please contact with admin or support center. We apologize for any inconvenience caused.</div><div><br></div><div>Meanwhile, click here to visit thenoura m5shop website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(7, 'account-unblock', 'customer', 'account-unblock', 'Account Unblocked', '<div><b>Hi {userName},</b></div><div><b><br></b></div><div>Your account has been successfully unblocked. We appreciate your cooperation in resolving this issue. Thank you for your understanding and patience. </div><div><br></div><div>Meanwhile, click here to visit thenoura m5 shop website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(8, 'digital-product-download', 'customer', 'digital-product-download', 'Congratulations', '<p>Thank you for choosing noura m5 shop! Your digital product is ready for download. To download your product use your email <b>{emailId}</b> and order # {orderId} below.</b><br></p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(9, 'digital-product-otp', 'customer', 'digital-product-otp', 'Digital Product Download OTP Verification', '<p><b>Hi {userName},</b></p><p>Your verification code is</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(10, 'add-fund-to-wallet', 'customer', 'add-fund-to-wallet', 'Transaction Successful', '<div style="text-align: center; ">Amount successfully credited to your wallet .</div><div style="text-align: center; "><br></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(11, 'registration', 'vendor', 'registration', 'Registration Complete', '<div><b>Hi {vendorName},</b></div><div><b><br></b></div><div>Congratulation! Your registration request has been send to admin successfully! Please wait until admin reviewal. </div><div><br></div><div>meanwhile click here to visit the noura m5 Shop Website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(12, 'registration-approved', 'vendor', 'registration-approved', 'Registration Approved', '<div><b>Hi {vendorName},</b></div><div><b><br></b></div><div>Your registration request has been approved by admin. Now you can complete your store setting and start selling your product on noura m5 Shop. </div><div><br></div><div>Meanwhile, click here to visit thenoura m5 shop website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(13, 'registration-denied', 'vendor', 'registration-denied', 'Registration Denied', '<div><b>Hi {vendorName},</b></div><div><b><br></b></div><div>Your registration request has been denied by admin. Please contact with admin or support center if you have any queries.</div><div><br></div><div>Meanwhile, click here to visit thenoura m5 shop website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(14, 'account-suspended', 'vendor', 'account-suspended', 'Account Suspended', '<div><b>Hi {vendorName},</b></div><div><b><br></b></div><div>Your account access has been suspended by admin.From now you can access your app and panel again Please contact us for any queries we’re always happy to help.</div><div><br></div><div>Meanwhile, click here to visit thenoura m5 shop website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(15, 'account-activation', 'vendor', 'account-activation', 'Account Activation', '<div><b>Hi {vendorName},</b></div><div><b><br></b></div><div>Your account suspension has been revoked by admin. From now you can access your app and panel again Please contact us for any queries we’re always happy to help.</div><div><br></div><div>Meanwhile, click here to visit thenoura m5 shop website</div><div><font color="#0000ff"> <a href="https://m5.nourpharm.com" target="_blank">https://m5.nourpharm.com</a></font></div>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(16, 'forgot-password', 'vendor', 'forgot-password', 'Change Password Request', '<p><b>Hi {vendorName},</b></p><p>Please click the link below to change your password.</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(17, 'order-received', 'vendor', 'order-received', 'New Order Received', '<p><b>Hi {vendorName},</b></p><p>We have sent you this email to notify that you have a new order.You will be able to see your orders after login to your panel.</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["icon","product_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25'),
	(18, 'reset-password-verification', 'delivery-man', 'reset-password-verification', 'OTP Verification For Password Reset', '<p><b>Hi {deliveryManName},</b></p><p>Your verification code is</p>', NULL, NULL, NULL, NULL, NULL, 'Please contact us for any queries, we’re always happy to help.', 'Copyright 2024 noura m5. All right reserved.', NULL, NULL, '["product_information","order_information","button_content","banner_image"]', 1, 1, 1, 1, '2024-07-07 11:00:25', '2024-07-07 11:00:25');

CREATE TABLE IF NOT EXISTS `emergency_contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `feature_deals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `flash_deals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `background_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `deal_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `flash_deal_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flash_deal_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `guest_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcm_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `guest_users` (`id`, `ip_address`, `fcm_token`, `created_at`, `updated_at`) VALUES
	(1, '::1', NULL, '2024-02-19 08:35:50', NULL),
	(2, '::1', NULL, '2024-03-27 03:10:49', NULL),
	(3, '::1', NULL, '2024-03-27 03:12:35', NULL),
	(4, '127.0.0.1', NULL, '2024-07-14 10:57:19', NULL),
	(22, '127.0.0.1', NULL, '2024-07-14 11:12:26', NULL),
	(23, '127.0.0.1', NULL, '2024-07-14 11:53:03', NULL),
	(24, '127.0.0.1', NULL, '2024-07-14 16:53:36', NULL),
	(25, '127.0.0.1', NULL, '2024-07-14 17:30:19', NULL),
	(26, '127.0.0.1', NULL, '2024-07-14 17:34:49', NULL),
	(27, '127.0.0.1', NULL, '2024-07-14 17:34:51', NULL),
	(28, '127.0.0.1', NULL, '2024-07-15 11:46:12', NULL),
	(29, '127.0.0.1', NULL, '2024-07-15 13:18:32', NULL),
	(30, '127.0.0.1', NULL, '2024-07-14 22:30:49', NULL),
	(31, '::1', NULL, '2024-07-15 19:55:42', NULL),
	(32, '127.0.0.1', NULL, '2024-07-15 19:58:05', NULL);

CREATE TABLE IF NOT EXISTS `help_topics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `answer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ranking` int NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `loyalty_point_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `transaction_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` decimal(24,3) NOT NULL DEFAULT '0.000',
  `debit` decimal(24,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(24,3) NOT NULL DEFAULT '0.000',
  `reference` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2020_09_08_105159_create_admins_table', 1),
	(5, '2020_09_08_111837_create_admin_roles_table', 1),
	(6, '2020_09_16_142451_create_categories_table', 2),
	(7, '2020_09_16_181753_create_categories_table', 3),
	(8, '2020_09_17_134238_create_brands_table', 4),
	(9, '2020_09_17_203054_create_attributes_table', 5),
	(10, '2020_09_19_112509_create_coupons_table', 6),
	(11, '2020_09_19_161802_create_curriencies_table', 7),
	(12, '2020_09_20_114509_create_sellers_table', 8),
	(13, '2020_09_23_113454_create_shops_table', 9),
	(14, '2020_09_23_115615_create_shops_table', 10),
	(15, '2020_09_23_153822_create_shops_table', 11),
	(16, '2020_09_21_122817_create_products_table', 12),
	(17, '2020_09_22_140800_create_colors_table', 12),
	(18, '2020_09_28_175020_create_products_table', 13),
	(19, '2020_09_28_180311_create_products_table', 14),
	(20, '2020_10_04_105041_create_search_functions_table', 15),
	(21, '2020_10_05_150730_create_customers_table', 15),
	(22, '2020_10_08_133548_create_wishlists_table', 16),
	(23, '2016_06_01_000001_create_oauth_auth_codes_table', 17),
	(24, '2016_06_01_000002_create_oauth_access_tokens_table', 17),
	(25, '2016_06_01_000003_create_oauth_refresh_tokens_table', 17),
	(26, '2016_06_01_000004_create_oauth_clients_table', 17),
	(27, '2016_06_01_000005_create_oauth_personal_access_clients_table', 17),
	(28, '2020_10_06_133710_create_product_stocks_table', 17),
	(29, '2020_10_06_134636_create_flash_deals_table', 17),
	(30, '2020_10_06_134719_create_flash_deal_products_table', 17),
	(31, '2020_10_08_115439_create_orders_table', 17),
	(32, '2020_10_08_115453_create_order_details_table', 17),
	(33, '2020_10_08_121135_create_shipping_addresses_table', 17),
	(34, '2020_10_10_171722_create_business_settings_table', 17),
	(35, '2020_09_19_161802_create_currencies_table', 18),
	(36, '2020_10_12_152350_create_reviews_table', 18),
	(37, '2020_10_12_161834_create_reviews_table', 19),
	(38, '2020_10_12_180510_create_support_tickets_table', 20),
	(39, '2020_10_14_140130_create_transactions_table', 21),
	(40, '2020_10_14_143553_create_customer_wallets_table', 21),
	(41, '2020_10_14_143607_create_customer_wallet_histories_table', 21),
	(42, '2020_10_22_142212_create_support_ticket_convs_table', 21),
	(43, '2020_10_24_234813_create_banners_table', 22),
	(44, '2020_10_27_111557_create_shipping_methods_table', 23),
	(45, '2020_10_27_114154_add_url_to_banners_table', 24),
	(46, '2020_10_28_170308_add_shipping_id_to_order_details', 25),
	(47, '2020_11_02_140528_add_discount_to_order_table', 26),
	(48, '2020_11_03_162723_add_column_to_order_details', 27),
	(49, '2020_11_08_202351_add_url_to_banners_table', 28),
	(50, '2020_11_10_112713_create_help_topic', 29),
	(51, '2020_11_10_141513_create_contacts_table', 29),
	(52, '2020_11_15_180036_add_address_column_user_table', 30),
	(53, '2020_11_18_170209_add_status_column_to_product_table', 31),
	(54, '2020_11_19_115453_add_featured_status_product', 32),
	(55, '2020_11_21_133302_create_deal_of_the_days_table', 33),
	(56, '2020_11_20_172332_add_product_id_to_products', 34),
	(57, '2020_11_27_234439_add__state_to_shipping_addresses', 34),
	(58, '2020_11_28_091929_create_chattings_table', 35),
	(59, '2020_12_02_011815_add_bank_info_to_sellers', 36),
	(60, '2020_12_08_193234_create_social_medias_table', 37),
	(61, '2020_12_13_122649_shop_id_to_chattings', 37),
	(62, '2020_12_14_145116_create_seller_wallet_histories_table', 38),
	(63, '2020_12_14_145127_create_seller_wallets_table', 38),
	(64, '2020_12_15_174804_create_admin_wallets_table', 39),
	(65, '2020_12_15_174821_create_admin_wallet_histories_table', 39),
	(66, '2020_12_15_214312_create_feature_deals_table', 40),
	(67, '2020_12_17_205712_create_withdraw_requests_table', 41),
	(68, '2021_02_22_161510_create_notifications_table', 42),
	(69, '2021_02_24_154706_add_deal_type_to_flash_deals', 43),
	(70, '2021_03_03_204349_add_cm_firebase_token_to_users', 44),
	(71, '2021_04_17_134848_add_column_to_order_details_stock', 45),
	(72, '2021_05_12_155401_add_auth_token_seller', 46),
	(73, '2021_06_03_104531_ex_rate_update', 47),
	(74, '2021_06_03_222413_amount_withdraw_req', 48),
	(75, '2021_06_04_154501_seller_wallet_withdraw_bal', 49),
	(76, '2021_06_04_195853_product_dis_tax', 50),
	(77, '2021_05_27_103505_create_product_translations_table', 51),
	(78, '2021_06_17_054551_create_soft_credentials_table', 51),
	(79, '2021_06_29_212549_add_active_col_user_table', 52),
	(80, '2021_06_30_212619_add_col_to_contact', 53),
	(81, '2021_07_01_160828_add_col_daily_needs_products', 54),
	(82, '2021_07_04_182331_add_col_seller_sales_commission', 55),
	(83, '2021_08_07_190655_add_seo_columns_to_products', 56),
	(84, '2021_08_07_205913_add_col_to_category_table', 56),
	(85, '2021_08_07_210808_add_col_to_shops_table', 56),
	(86, '2021_08_14_205216_change_product_price_col_type', 56),
	(87, '2021_08_16_201505_change_order_price_col', 56),
	(88, '2021_08_16_201552_change_order_details_price_col', 56),
	(89, '2019_09_29_154000_create_payment_cards_table', 57),
	(90, '2021_08_17_213934_change_col_type_seller_earning_history', 57),
	(91, '2021_08_17_214109_change_col_type_admin_earning_history', 57),
	(92, '2021_08_17_214232_change_col_type_admin_wallet', 57),
	(93, '2021_08_17_214405_change_col_type_seller_wallet', 57),
	(94, '2021_08_22_184834_add_publish_to_products_table', 57),
	(95, '2021_09_08_211832_add_social_column_to_users_table', 57),
	(96, '2021_09_13_165535_add_col_to_user', 57),
	(97, '2021_09_19_061647_add_limit_to_coupons_table', 57),
	(98, '2021_09_20_020716_add_coupon_code_to_orders_table', 57),
	(99, '2021_09_23_003059_add_gst_to_sellers_table', 57),
	(100, '2021_09_28_025411_create_order_transactions_table', 57),
	(101, '2021_10_02_185124_create_carts_table', 57),
	(102, '2021_10_02_190207_create_cart_shippings_table', 57),
	(103, '2021_10_03_194334_add_col_order_table', 57),
	(104, '2021_10_03_200536_add_shipping_cost', 57),
	(105, '2021_10_04_153201_add_col_to_order_table', 57),
	(106, '2021_10_07_172701_add_col_cart_shop_info', 57),
	(107, '2021_10_07_184442_create_phone_or_email_verifications_table', 57),
	(108, '2021_10_07_185416_add_user_table_email_verified', 57),
	(109, '2021_10_11_192739_add_transaction_amount_table', 57),
	(110, '2021_10_11_200850_add_order_verification_code', 57),
	(111, '2021_10_12_083241_add_col_to_order_transaction', 57),
	(112, '2021_10_12_084440_add_seller_id_to_order', 57),
	(113, '2021_10_12_102853_change_col_type', 57),
	(114, '2021_10_12_110434_add_col_to_admin_wallet', 57),
	(115, '2021_10_12_110829_add_col_to_seller_wallet', 57),
	(116, '2021_10_13_091801_add_col_to_admin_wallets', 57),
	(117, '2021_10_13_092000_add_col_to_seller_wallets_tax', 57),
	(118, '2021_10_13_165947_rename_and_remove_col_seller_wallet', 57),
	(119, '2021_10_13_170258_rename_and_remove_col_admin_wallet', 57),
	(120, '2021_10_14_061603_column_update_order_transaction', 57),
	(121, '2021_10_15_103339_remove_col_from_seller_wallet', 57),
	(122, '2021_10_15_104419_add_id_col_order_tran', 57),
	(123, '2021_10_15_213454_update_string_limit', 57),
	(124, '2021_10_16_234037_change_col_type_translation', 57),
	(125, '2021_10_16_234329_change_col_type_translation_1', 57),
	(126, '2021_10_27_091250_add_shipping_address_in_order', 58),
	(127, '2021_01_24_205114_create_paytabs_invoices_table', 59),
	(128, '2021_11_20_043814_change_pass_reset_email_col', 59),
	(129, '2021_11_25_043109_create_delivery_men_table', 60),
	(130, '2021_11_25_062242_add_auth_token_delivery_man', 60),
	(131, '2021_11_27_043405_add_deliveryman_in_order_table', 60),
	(132, '2021_11_27_051432_create_delivery_histories_table', 60),
	(133, '2021_11_27_051512_add_fcm_col_for_delivery_man', 60),
	(134, '2021_12_15_123216_add_columns_to_banner', 60),
	(135, '2022_01_04_100543_add_order_note_to_orders_table', 60),
	(136, '2022_01_10_034952_add_lat_long_to_shipping_addresses_table', 60),
	(137, '2022_01_10_045517_create_billing_addresses_table', 60),
	(138, '2022_01_11_040755_add_is_billing_to_shipping_addresses_table', 60),
	(139, '2022_01_11_053404_add_billing_to_orders_table', 60),
	(140, '2022_01_11_234310_add_firebase_toke_to_sellers_table', 60),
	(141, '2022_01_16_121801_change_colu_type', 60),
	(142, '2022_01_22_101601_change_cart_col_type', 61),
	(143, '2022_01_23_031359_add_column_to_orders_table', 61),
	(144, '2022_01_28_235054_add_status_to_admins_table', 61),
	(145, '2022_02_01_214654_add_pos_status_to_sellers_table', 61),
	(146, '2019_12_14_000001_create_personal_access_tokens_table', 62),
	(147, '2022_02_11_225355_add_checked_to_orders_table', 62),
	(148, '2022_02_14_114359_create_refund_requests_table', 62),
	(149, '2022_02_14_115757_add_refund_request_to_order_details_table', 62),
	(150, '2022_02_15_092604_add_order_details_id_to_transactions_table', 62),
	(151, '2022_02_15_121410_create_refund_transactions_table', 62),
	(152, '2022_02_24_091236_add_multiple_column_to_refund_requests_table', 62),
	(153, '2022_02_24_103827_create_refund_statuses_table', 62),
	(154, '2022_03_01_121420_add_refund_id_to_refund_transactions_table', 62),
	(155, '2022_03_10_091943_add_priority_to_categories_table', 63),
	(156, '2022_03_13_111914_create_shipping_types_table', 63),
	(157, '2022_03_13_121514_create_category_shipping_costs_table', 63),
	(158, '2022_03_14_074413_add_four_column_to_products_table', 63),
	(159, '2022_03_15_105838_add_shipping_to_carts_table', 63),
	(160, '2022_03_16_070327_add_shipping_type_to_orders_table', 63),
	(161, '2022_03_17_070200_add_delivery_info_to_orders_table', 63),
	(162, '2022_03_18_143339_add_shipping_type_to_carts_table', 63),
	(163, '2022_04_06_020313_create_subscriptions_table', 64),
	(164, '2022_04_12_233704_change_column_to_products_table', 64),
	(165, '2022_04_19_095926_create_jobs_table', 64),
	(166, '2022_05_12_104247_create_wallet_transactions_table', 65),
	(167, '2022_05_12_104511_add_two_column_to_users_table', 65),
	(168, '2022_05_14_063309_create_loyalty_point_transactions_table', 65),
	(169, '2022_05_26_044016_add_user_type_to_password_resets_table', 65),
	(170, '2022_04_15_235820_add_provider', 66),
	(171, '2022_07_21_101659_add_code_to_products_table', 66),
	(172, '2022_07_26_103744_add_notification_count_to_notifications_table', 66),
	(173, '2022_07_31_031541_add_minimum_order_qty_to_products_table', 66),
	(174, '2022_08_11_172839_add_product_type_and_digital_product_type_and_digital_file_ready_to_products', 67),
	(175, '2022_08_11_173941_add_product_type_and_digital_product_type_and_digital_file_to_order_details', 67),
	(176, '2022_08_20_094225_add_product_type_and_digital_product_type_and_digital_file_ready_to_carts_table', 67),
	(177, '2022_10_04_160234_add_banking_columns_to_delivery_men_table', 68),
	(178, '2022_10_04_161339_create_deliveryman_wallets_table', 68),
	(179, '2022_10_04_184506_add_deliverymanid_column_to_withdraw_requests_table', 68),
	(180, '2022_10_11_103011_add_deliverymans_columns_to_chattings_table', 68),
	(181, '2022_10_11_144902_add_deliverman_id_cloumn_to_reviews_table', 68),
	(182, '2022_10_17_114744_create_order_status_histories_table', 68),
	(183, '2022_10_17_120840_create_order_expected_delivery_histories_table', 68),
	(184, '2022_10_18_084245_add_deliveryman_charge_and_expected_delivery_date', 68),
	(185, '2022_10_18_130938_create_delivery_zip_codes_table', 68),
	(186, '2022_10_18_130956_create_delivery_country_codes_table', 68),
	(187, '2022_10_20_164712_create_delivery_man_transactions_table', 68),
	(188, '2022_10_27_145604_create_emergency_contacts_table', 68),
	(189, '2022_10_29_182930_add_is_pause_cause_to_orders_table', 68),
	(190, '2022_10_31_150604_add_address_phone_country_code_column_to_delivery_men_table', 68),
	(191, '2022_11_05_185726_add_order_id_to_reviews_table', 68),
	(192, '2022_11_07_190749_create_deliveryman_notifications_table', 68),
	(193, '2022_11_08_132745_change_transaction_note_type_to_withdraw_requests_table', 68),
	(194, '2022_11_10_193747_chenge_order_amount_seller_amount_admin_commission_delivery_charge_tax_toorder_transactions_table', 68),
	(195, '2022_12_17_035723_few_field_add_to_coupons_table', 69),
	(196, '2022_12_26_231606_add_coupon_discount_bearer_and_admin_commission_to_orders', 69),
	(197, '2023_01_04_003034_alter_billing_addresses_change_zip', 69),
	(198, '2023_01_05_121600_change_id_to_transactions_table', 69),
	(199, '2023_02_02_113330_create_product_tag_table', 70),
	(200, '2023_02_02_114518_create_tags_table', 70),
	(201, '2023_02_02_152248_add_tax_model_to_products_table', 70),
	(202, '2023_02_02_152718_add_tax_model_to_order_details_table', 70),
	(203, '2023_02_02_171034_add_tax_type_to_carts', 70),
	(204, '2023_02_06_124447_add_color_image_column_to_products_table', 70),
	(205, '2023_02_07_120136_create_withdrawal_methods_table', 70),
	(206, '2023_02_07_175939_add_withdrawal_method_id_and_withdrawal_method_fields_to_withdraw_requests_table', 70),
	(207, '2023_02_08_143314_add_vacation_start_and_vacation_end_and_vacation_not_column_to_shops_table', 70),
	(208, '2023_02_09_104656_add_payment_by_and_payment_not_to_orders_table', 70),
	(209, '2023_03_27_150723_add_expires_at_to_phone_or_email_verifications', 71),
	(210, '2023_04_17_095721_create_shop_followers_table', 71),
	(211, '2023_04_17_111249_add_bottom_banner_to_shops_table', 71),
	(212, '2023_04_20_125423_create_product_compares_table', 71),
	(213, '2023_04_30_165642_add_category_sub_category_and_sub_sub_category_add_in_product_table', 71),
	(214, '2023_05_16_131006_add_expires_at_to_password_resets', 71),
	(215, '2023_05_17_044243_add_visit_count_to_tags_table', 71),
	(216, '2023_05_18_000403_add_title_and_subtitle_and_background_color_and_button_text_to_banners_table', 71),
	(217, '2023_05_21_111300_add_login_hit_count_and_is_temp_blocked_and_temp_block_time_to_users_table', 71),
	(218, '2023_05_21_111600_add_login_hit_count_and_is_temp_blocked_and_temp_block_time_to_phone_or_email_verifications_table', 71),
	(219, '2023_05_21_112215_add_login_hit_count_and_is_temp_blocked_and_temp_block_time_to_password_resets_table', 71),
	(220, '2023_06_04_210726_attachment_lenght_change_to_reviews_table', 71),
	(221, '2023_06_05_115153_add_referral_code_and_referred_by_to_users_table', 72),
	(222, '2023_06_21_002658_add_offer_banner_to_shops_table', 72),
	(223, '2023_07_08_210747_create_most_demandeds_table', 72),
	(224, '2023_07_31_111419_add_minimum_order_amount_to_sellers_table', 72),
	(225, '2023_08_03_105256_create_offline_payment_methods_table', 72),
	(226, '2023_08_07_131013_add_is_guest_column_to_carts_table', 72),
	(227, '2023_08_07_170601_create_offline_payments_table', 72),
	(228, '2023_08_12_102355_create_add_fund_bonus_categories_table', 72),
	(229, '2023_08_12_215346_create_guest_users_table', 72),
	(230, '2023_08_12_215659_add_is_guest_column_to_orders_table', 72),
	(231, '2023_08_12_215933_add_is_guest_column_to_shipping_addresses_table', 72),
	(232, '2023_08_15_000957_add_email_column_toshipping_address_table', 72),
	(233, '2023_08_17_222330_add_identify_related_columns_to_admins_table', 72),
	(234, '2023_08_20_230624_add_sent_by_and_send_to_in_notifications_table', 72),
	(235, '2023_08_20_230911_create_notification_seens_table', 72),
	(236, '2023_08_21_042331_add_theme_to_banners_table', 72),
	(237, '2023_08_24_150009_add_free_delivery_over_amount_and_status_to_seller_table', 72),
	(238, '2023_08_26_161214_add_is_shipping_free_to_orders_table', 72),
	(239, '2023_08_26_173523_add_payment_method_column_to_wallet_transactions_table', 72),
	(240, '2023_08_26_204653_add_verification_status_column_to_orders_table', 72),
	(241, '2023_08_26_225113_create_order_delivery_verifications_table', 72),
	(242, '2023_09_03_212200_add_free_delivery_responsibility_column_to_orders_table', 72),
	(243, '2023_09_23_153314_add_shipping_responsibility_column_to_orders_table', 72),
	(244, '2023_09_25_152733_create_digital_product_otp_verifications_table', 72),
	(245, '2023_09_27_191638_add_attachment_column_to_support_ticket_convs_table', 73),
	(246, '2023_10_01_205117_add_attachment_column_to_chattings_table', 73),
	(247, '2023_10_07_182714_create_notification_messages_table', 73),
	(248, '2023_10_21_113354_add_app_language_column_to_users_table', 73),
	(249, '2023_10_21_123433_add_app_language_column_to_sellers_table', 73),
	(250, '2023_10_21_124657_add_app_language_column_to_delivery_men_table', 73),
	(251, '2023_10_22_130225_add_attachment_to_support_tickets_table', 73),
	(252, '2023_10_25_113233_make_message_nullable_in_chattings_table', 73),
	(253, '2023_10_30_152005_make_attachment_column_type_change_to_reviews_table', 73),
	(254, '2024_01_14_192546_add_slug_to_shops_table', 74),
	(255, '2024_01_25_175421_add_country_code_to_emergency_contacts_table', 75),
	(256, '2024_02_01_200417_add_denied_count_and_approved_count_to_refund_requests_table', 75),
	(257, '2024_03_11_130425_add_seen_notification_and_notification_receiver_to_chattings_table', 76),
	(258, '2024_03_12_123322_update_images_column_in_refund_requests_table', 76),
	(259, '2024_03_21_134659_change_denied_note_column_type_to_text', 76),
	(264, '2024_04_23_130436_create_customer_balances_table', 77),
	(265, '2024_04_23_130436_create_customer_slices_table', 78),
	(266, '2024_04_24_093938_add_slice_id_to_users_table', 79);

CREATE TABLE IF NOT EXISTS `most_demandeds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `banner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sent_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `sent_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'customer',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_count` int NOT NULL DEFAULT '0',
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `notification_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `notification_messages` (`id`, `user_type`, `key`, `message`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'customer', 'order_pending_message', 'order pen message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(2, 'customer', 'order_confirmation_message', 'Order con Message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(3, 'customer', 'order_processing_message', 'Order pro Message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(4, 'customer', 'out_for_delivery_message', 'Order ouut Message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(5, 'customer', 'order_delivered_message', 'Order del Message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(6, 'customer', 'order_returned_message', 'Order hh Message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(7, 'customer', 'order_failed_message', 'Order fa Message', 0, '2023-10-30 11:02:55', '2024-03-27 03:12:32'),
	(8, 'customer', 'order_canceled', '', 0, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(9, 'customer', 'order_refunded_message', 'customize your order refunded message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(10, 'customer', 'refund_request_canceled_message', 'customize your refund request canceled message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(11, 'customer', 'message_from_delivery_man', 'customize your message from delivery man message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(12, 'customer', 'message_from_seller', 'customize your message from seller message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(13, 'customer', 'fund_added_by_admin_message', 'customize your fund added by admin message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(14, 'seller', 'new_order_message', 'customize your new order message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(15, 'seller', 'refund_request_message', 'customize your refund request message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(16, 'seller', 'order_edit_message', 'customize your order edit message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(17, 'seller', 'withdraw_request_status_message', 'customize your withdraw request status message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(18, 'seller', 'message_from_customer', 'customize your message from customer message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(19, 'seller', 'delivery_man_assign_by_admin_message', 'customize your delivery man assign by admin message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(20, 'seller', 'order_delivered_message', 'customize your order delivered message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(21, 'seller', 'order_canceled', 'customize your order canceled message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(22, 'seller', 'order_refunded_message', 'customize your order refunded message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(23, 'seller', 'refund_request_canceled_message', 'customize your refund request canceled message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(24, 'seller', 'refund_request_status_changed_by_admin', 'customize your refund request status changed by admin message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(25, 'delivery_man', 'new_order_assigned_message', '', 0, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(26, 'delivery_man', 'expected_delivery_date', '', 0, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(27, 'delivery_man', 'delivery_man_charge', 'customize your delivery man charge message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(28, 'delivery_man', 'order_canceled', 'customize your order canceled message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(29, 'delivery_man', 'order_rescheduled_message', 'customize your order rescheduled message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(30, 'delivery_man', 'order_edit_message', 'customize your order edit message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(31, 'delivery_man', 'message_from_seller', 'customize your message from seller message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(32, 'delivery_man', 'message_from_admin', 'customize your message from admin message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(33, 'delivery_man', 'message_from_customer', 'customize your message from customer message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(34, 'delivery_man', 'cash_collect_by_admin_message', 'customize your cash collect by admin message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(35, 'delivery_man', 'cash_collect_by_seller_message', 'customize your cash collect by seller message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(36, 'delivery_man', 'withdraw_request_status_message', 'customize your withdraw request status message message', 1, '2023-10-30 11:02:55', '2023-10-30 11:02:55'),
	(37, 'seller', 'product_request_approved_message', 'customize your product request approved message message', 1, '2024-02-19 08:35:38', '2024-02-19 08:35:38'),
	(38, 'seller', 'product_request_rejected_message', 'customize your product request rejected message message', 1, '2024-02-19 08:35:38', '2024-02-19 08:35:38');

CREATE TABLE IF NOT EXISTS `notification_seens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `notification_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `client_id` int unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
	('6840b7d4ed685bf2e0dc593affa0bd3b968065f47cc226d39ab09f1422b5a1d9666601f3f60a79c1', 98, 1, 'LaravelAuthApp', '[]', 1, '2021-07-05 09:25:41', '2021-07-05 09:25:41', '2022-07-05 15:25:41'),
	('c42cdd5ae652b8b2cbac4f2f4b496e889e1a803b08672954c8bbe06722b54160e71dce3e02331544', 98, 1, 'LaravelAuthApp', '[]', 1, '2021-07-05 09:24:36', '2021-07-05 09:24:36', '2022-07-05 15:24:36');

CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `client_id` int unsigned NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `provider` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`, `provider`) VALUES
	(1, NULL, '6amtech', 'GEUx5tqkviM6AAQcz4oi1dcm1KtRdJPgw41lj0eI', 'http://localhost', 1, 0, 0, '2020-10-21 18:27:22', '2020-10-21 18:27:22', NULL);

CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
	(1, 1, '2020-10-21 18:27:23', '2020-10-21 18:27:23');

CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `offline_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `payment_info` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `offline_payment_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `method_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_informations` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_guest` tinyint NOT NULL DEFAULT '0',
  `customer_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `order_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_ref` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order_amount` double NOT NULL DEFAULT '0',
  `admin_commission` decimal(8,2) NOT NULL DEFAULT '0.00',
  `is_pause` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cause` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `discount_amount` double NOT NULL DEFAULT '0',
  `discount_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_discount_bearer` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inhouse',
  `shipping_responsibility` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_method_id` bigint NOT NULL DEFAULT '0',
  `shipping_cost` double(8,2) NOT NULL DEFAULT '0.00',
  `is_shipping_free` tinyint(1) NOT NULL DEFAULT '0',
  `order_group_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def-order-group',
  `verification_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `verification_status` tinyint NOT NULL DEFAULT '0',
  `seller_id` bigint DEFAULT NULL,
  `seller_is` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `delivery_man_id` bigint DEFAULT NULL,
  `deliveryman_charge` double NOT NULL DEFAULT '0',
  `expected_delivery_date` date DEFAULT NULL,
  `order_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `billing_address` bigint unsigned DEFAULT NULL,
  `billing_address_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default_type',
  `extra_discount` double(8,2) NOT NULL DEFAULT '0.00',
  `extra_discount_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `free_delivery_bearer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `shipping_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_service_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `third_party_delivery_tracking_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100032 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `orders` (`id`, `customer_id`, `is_guest`, `customer_type`, `payment_status`, `order_status`, `payment_method`, `transaction_ref`, `payment_by`, `payment_note`, `order_amount`, `admin_commission`, `is_pause`, `cause`, `shipping_address`, `created_at`, `updated_at`, `discount_amount`, `discount_type`, `coupon_code`, `coupon_discount_bearer`, `shipping_responsibility`, `shipping_method_id`, `shipping_cost`, `is_shipping_free`, `order_group_id`, `verification_code`, `verification_status`, `seller_id`, `seller_is`, `shipping_address_data`, `delivery_man_id`, `deliveryman_charge`, `expected_delivery_date`, `order_note`, `billing_address`, `billing_address_data`, `order_type`, `extra_discount`, `extra_discount_type`, `free_delivery_bearer`, `checked`, `shipping_type`, `delivery_type`, `delivery_service_name`, `third_party_delivery_tracking_id`) VALUES
	(100001, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 160, 0.00, '0', NULL, '1', '2024-07-14 14:35:03', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '1491-RD4dj-1720956903', '337457', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"sdfsdf sdfsdf","email":null,"address_type":"home","address":"sdcsdf","city":"sdsdsd","zip":"332","phone":"+2010008275881","created_at":null,"updated_at":null,"state":null,"country":"Anguilla","latitude":"-33.874173330831326","longitude":"151.21629565342377","is_billing":false}', NULL, 0, NULL, 'kjiuitut', 2, '{"id":2,"customer_id":"2","is_guest":false,"contact_person_name":"dfsfds","email":null,"address_type":"home","address":"fgjh","city":"nmjhkh","zip":"534","phone":"+201008275881","created_at":null,"updated_at":null,"state":null,"country":"Anguilla","latitude":"-33.87760809349691","longitude":"151.19947283848236","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100002, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 14:49:38', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '3243-j2uD2-1720957778', '380636', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Zephr Shepherd","email":null,"address_type":"home","address":"Qui vel aute cupidit","city":"Incididunt veritatis","zip":"94357","phone":"+119971944913","created_at":null,"updated_at":"2024-07-14T11:49:17.000000Z","state":null,"country":"United States Minor Outlying Islands","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, 'xdgdf', 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Zephr Shepherd","email":null,"address_type":"home","address":"Qui vel aute cupidit","city":"Incididunt veritatis","zip":"94357","phone":"+119971944913","created_at":null,"updated_at":"2024-07-14T11:49:17.000000Z","state":null,"country":"United States Minor Outlying Islands","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100003, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '3', '2024-07-14 15:00:11', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '8742-8niGl-1720958411', '500217', 0, 1, 'admin', '{"id":3,"customer_id":"0","is_guest":false,"contact_person_name":"Hyacinth Bray","email":null,"address_type":"others","address":"Voluptatem et aperia","city":"Labore blanditiis la","zip":"54573","phone":"+114077951202","created_at":null,"updated_at":null,"state":null,"country":"Germany","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, 'pioio', 3, '{"id":3,"customer_id":"0","is_guest":false,"contact_person_name":"Hyacinth Bray","email":null,"address_type":"others","address":"Voluptatem et aperia","city":"Labore blanditiis la","zip":"54573","phone":"+114077951202","created_at":null,"updated_at":null,"state":null,"country":"Germany","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100004, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 15:02:55', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '3763-f42zM-1720958575', '962506', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Nadine Mayo","email":null,"address_type":"home","address":"Provident veniam l","city":"Totam recusandae Si","zip":"52916","phone":"+112531761895","created_at":null,"updated_at":"2024-07-14T12:02:15.000000Z","state":null,"country":"Paraguay","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Nadine Mayo","email":null,"address_type":"home","address":"Provident veniam l","city":"Totam recusandae Si","zip":"52916","phone":"+112531761895","created_at":null,"updated_at":"2024-07-14T12:02:15.000000Z","state":null,"country":"Paraguay","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100005, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 15:14:11', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '1739-se5Uy-1720959251', '623194', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Samantha Ewing","email":null,"address_type":"home","address":"Omnis perspiciatis ","city":"Dolorem sed aspernat","zip":"22265","phone":"+116547959075","created_at":null,"updated_at":"2024-07-14T12:05:32.000000Z","state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Samantha Ewing","email":null,"address_type":"home","address":"Omnis perspiciatis ","city":"Dolorem sed aspernat","zip":"22265","phone":"+116547959075","created_at":null,"updated_at":"2024-07-14T12:05:32.000000Z","state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100006, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 15:42:24', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '4797-5DFL6-1720960944', '203390', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Joseph Melton","email":null,"address_type":"others","address":"Similique excepturi ","city":"Alias omnis et rerum","zip":"87452","phone":"+116467474955","created_at":null,"updated_at":"2024-07-14T12:20:03.000000Z","state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 4, '{"id":4,"customer_id":"0","is_guest":false,"contact_person_name":"Ulla Madden","email":null,"address_type":"home","address":"Distinctio Molestia","city":"Irure ratione ut vel","zip":"49512","phone":"+116521991894","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100007, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 160, 0.00, '0', NULL, '6', '2024-07-14 17:18:27', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '5115-zxMGI-1720966707', '153814', 0, 1, 'admin', '{"id":6,"customer_id":"0","is_guest":false,"contact_person_name":"Raymond Lane","email":null,"address_type":"others","address":"Officia sit pariatu","city":"Ipsum voluptatem At","zip":"29306","phone":"+112234115554","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 6, '{"id":6,"customer_id":"0","is_guest":false,"contact_person_name":"Raymond Lane","email":null,"address_type":"others","address":"Officia sit pariatu","city":"Ipsum voluptatem At","zip":"29306","phone":"+112234115554","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100008, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 160, 0.00, '0', NULL, '6', '2024-07-14 17:19:27', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '6815-3Vd5M-1720966767', '172484', 0, 1, 'admin', '{"id":6,"customer_id":"0","is_guest":false,"contact_person_name":"Raymond Lane","email":null,"address_type":"others","address":"Officia sit pariatu","city":"Ipsum voluptatem At","zip":"29306","phone":"+112234115554","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 6, '{"id":6,"customer_id":"0","is_guest":false,"contact_person_name":"Raymond Lane","email":null,"address_type":"others","address":"Officia sit pariatu","city":"Ipsum voluptatem At","zip":"29306","phone":"+112234115554","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100009, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 17:23:08', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '1399-gzdXp-1720966988', '976103', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":"2024-07-14T14:22:33.000000Z","state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, 'oipo', 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":"2024-07-14T14:22:33.000000Z","state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100010, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '7', '2024-07-14 17:35:05', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '8298-2GTHB-1720967705', '834072', 0, 1, 'admin', '{"id":7,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 8, '{"id":8,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100011, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '9', '2024-07-14 17:46:50', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '2965-eSuG9-1720968410', '562059', 0, 1, 'admin', '{"id":9,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 10, '{"id":10,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100012, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '9', '2024-07-14 17:47:32', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '4460-QjO9B-1720968451', '844800', 0, 1, 'admin', '{"id":9,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 10, '{"id":10,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100013, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '9', '2024-07-14 17:48:28', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '5085-lLpAi-1720968508', '252471', 0, 1, 'admin', '{"id":9,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 10, '{"id":10,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100014, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '9', '2024-07-14 17:50:52', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '4694-5WKap-1720968652', '442501', 0, 1, 'admin', '{"id":9,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 10, '{"id":10,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100015, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '11', '2024-07-14 17:53:22', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '6402-4GUdk-1720968802', '653702', 0, 1, 'admin', '{"id":11,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 12, '{"id":12,"customer_id":"0","is_guest":false,"contact_person_name":"Daria Leonard","email":null,"address_type":"others","address":"Officiis ipsum esse","city":"Sit debitis molestia","zip":"44320","phone":"+119321559263","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100016, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '13', '2024-07-14 17:55:18', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '5873-fCj9L-1720968918', '290734', 0, 1, 'admin', '{"id":13,"customer_id":"0","is_guest":false,"contact_person_name":"Austin Waller","email":null,"address_type":"permanent","address":"Dolores ut totam obc","city":"Voluptas illo rerum ","zip":"12251","phone":"+117145714981","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 14, '{"id":14,"customer_id":"0","is_guest":false,"contact_person_name":"Honorato Blake","email":null,"address_type":"permanent","address":"Eos sit laboris sin","city":"Doloribus excepteur ","zip":"45478","phone":"+111038891674","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100017, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '13', '2024-07-14 17:55:46', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '2211-lcylV-1720968946', '320465', 0, 1, 'admin', '{"id":13,"customer_id":"0","is_guest":false,"contact_person_name":"Austin Waller","email":null,"address_type":"permanent","address":"Dolores ut totam obc","city":"Voluptas illo rerum ","zip":"12251","phone":"+117145714981","created_at":null,"updated_at":null,"state":null,"country":"Palau","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 14, '{"id":14,"customer_id":"0","is_guest":false,"contact_person_name":"Honorato Blake","email":null,"address_type":"permanent","address":"Eos sit laboris sin","city":"Doloribus excepteur ","zip":"45478","phone":"+111038891674","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100018, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:02:11', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '6656-Z0zra-1720969331', '361889', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100019, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:02:35', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '3740-DhDsp-1720969355', '656027', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100020, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:03:44', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '7804-FECyS-1720969424', '982238', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100021, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:04:54', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '1338-1qNyJ-1720969494', '277220', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100022, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:05:12', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '8698-OwRUy-1720969512', '362835', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100023, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:06:17', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '9930-uClrM-1720969577', '369368', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100024, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:10:11', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '1188-OUtYJ-1720969811', '708132', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100025, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:10:16', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '9678-qHcNo-1720969816', '495958', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100026, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:10:36', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '1154-npztX-1720969836', '913033', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100027, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:10:39', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '9432-we9Tf-1720969839', '959945', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100028, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:11:56', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '6839-7jifl-1720969916', '533341', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100029, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:12:02', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '2250-oJSqM-1720969921', '809573', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100030, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 80, 0.00, '0', NULL, '1', '2024-07-14 18:12:20', '2024-07-15 13:19:26', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '3922-QkFDV-1720969940', '342340', 0, 1, 'admin', '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 1, '{"id":1,"customer_id":"2","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":"2024-07-14T15:01:29.000000Z","state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL),
	(100031, '2', 0, 'customer', 'unpaid', 'pending', 'cash_on_delivery', '', NULL, NULL, 480, 0.00, '0', NULL, '15', '2024-07-15 21:13:35', '2024-07-15 21:14:20', 0, NULL, '0', 'inhouse', 'inhouse_shipping', 0, 0.00, 0, '4368-aTYq1-1721067215', '798123', 0, 1, 'admin', '{"id":15,"customer_id":"0","is_guest":false,"contact_person_name":"Tanner Colefdgfd","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":false}', NULL, 0, NULL, NULL, 16, '{"id":16,"customer_id":"0","is_guest":false,"contact_person_name":"Tanner Cole","email":null,"address_type":"others","address":"Dolorem est modi num","city":"Sed ut culpa labore ","zip":"24675","phone":"+117981199233","created_at":null,"updated_at":null,"state":null,"country":"Afghanistan","latitude":"0","longitude":"0","is_billing":true}', 'default_type', 0.00, NULL, 'admin', 1, 'product_wise', NULL, NULL, NULL);

CREATE TABLE IF NOT EXISTS `order_delivery_verifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `order_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `seller_id` bigint DEFAULT NULL,
  `digital_file_after_sell` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `qty` int NOT NULL DEFAULT '0',
  `price` double NOT NULL DEFAULT '0',
  `tax` double NOT NULL DEFAULT '0',
  `discount` double NOT NULL DEFAULT '0',
  `tax_model` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'exclude',
  `delivery_status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shipping_method_id` bigint DEFAULT NULL,
  `variant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_stock_decreased` tinyint(1) NOT NULL DEFAULT '1',
  `refund_request` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `order_details` (`id`, `order_id`, `product_id`, `seller_id`, `digital_file_after_sell`, `product_details`, `qty`, `price`, `tax`, `discount`, `tax_model`, `delivery_status`, `payment_status`, `created_at`, `updated_at`, `shipping_method_id`, `variant`, `variation`, `discount_type`, `is_stock_decreased`, `refund_request`) VALUES
	(1, 100001, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":55,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T08:16:16.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 14:35:03', '2024-07-14 14:35:03', NULL, '', '[]', 'discount_on_product', 1, 0),
	(2, 100001, 3, 1, NULL, '{"id":3,"added_by":"admin","user_id":1,"name":"iiiiiiiii","slug":"iiiiiiiii-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":55,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T08:16:16.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 14:35:03', '2024-07-14 14:35:03', NULL, '', '[]', 'discount_on_product', 1, 0),
	(3, 100002, 3, 1, NULL, '{"id":3,"added_by":"admin","user_id":1,"name":"iiiiiiiii","slug":"iiiiiiiii-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":54,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T11:35:03.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 14:49:38', '2024-07-14 14:49:38', NULL, '', '[]', 'discount_on_product', 1, 0),
	(4, 100003, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":54,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T11:35:03.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 15:00:11', '2024-07-14 15:00:11', NULL, '', '[]', 'discount_on_product', 1, 0),
	(5, 100004, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":53,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T12:00:11.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 15:02:56', '2024-07-14 15:02:56', NULL, '', '[]', 'discount_on_product', 1, 0),
	(6, 100005, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":52,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T12:02:56.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 15:14:11', '2024-07-14 15:14:11', NULL, '', '[]', 'discount_on_product', 1, 0),
	(7, 100006, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":51,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T12:14:11.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 15:42:24', '2024-07-14 15:42:24', NULL, '', '[]', 'discount_on_product', 1, 0),
	(8, 100007, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":50,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T12:42:24.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:18:27', '2024-07-14 17:18:27', NULL, '', '[]', 'discount_on_product', 1, 0),
	(9, 100008, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":49,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:18:27.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:19:27', '2024-07-14 17:19:27', NULL, '', '[]', 'discount_on_product', 1, 0),
	(10, 100008, 1, 1, NULL, '{"id":1,"added_by":"admin","user_id":1,"name":"assaasas","slug":"assaasas-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":48,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:19:27.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:19:27', '2024-07-14 17:19:27', NULL, '', '[]', 'discount_on_product', 1, 0),
	(11, 100009, 3, 1, NULL, '{"id":3,"added_by":"admin","user_id":1,"name":"iiiiiiiii","slug":"iiiiiiiii-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":2,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":53,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T11:49:38.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:23:08', '2024-07-14 17:23:08', NULL, '', '[]', 'discount_on_product', 1, 0),
	(12, 100010, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":55,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T08:16:16.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:35:05', '2024-07-14 17:35:05', NULL, '', '[]', 'discount_on_product', 1, 0),
	(13, 100013, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":54,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:35:05.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:48:28', '2024-07-14 17:48:28', NULL, '', '[]', 'discount_on_product', 1, 0),
	(14, 100014, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":53,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:48:28.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:50:52', '2024-07-14 17:50:52', NULL, '', '[]', 'discount_on_product', 1, 0),
	(15, 100015, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":52,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:50:52.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:53:22', '2024-07-14 17:53:22', NULL, '', '[]', 'discount_on_product', 1, 0),
	(16, 100016, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":51,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:53:22.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:55:18', '2024-07-14 17:55:18', NULL, '', '[]', 'discount_on_product', 1, 0),
	(17, 100017, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":50,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:55:18.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 17:55:46', '2024-07-14 17:55:46', NULL, '', '[]', 'discount_on_product', 1, 0),
	(18, 100018, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":49,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T14:55:46.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:02:11', '2024-07-14 18:02:11', NULL, '', '[]', 'discount_on_product', 1, 0),
	(19, 100019, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":48,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:02:11.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:02:35', '2024-07-14 18:02:35', NULL, '', '[]', 'discount_on_product', 1, 0),
	(20, 100020, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":47,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:02:35.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:03:44', '2024-07-14 18:03:44', NULL, '', '[]', 'discount_on_product', 1, 0),
	(21, 100021, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":46,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:03:44.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:04:54', '2024-07-14 18:04:54', NULL, '', '[]', 'discount_on_product', 1, 0),
	(22, 100022, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":45,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:04:54.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:05:12', '2024-07-14 18:05:12', NULL, '', '[]', 'discount_on_product', 1, 0),
	(23, 100023, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":44,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:05:12.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:06:17', '2024-07-14 18:06:17', NULL, '', '[]', 'discount_on_product', 1, 0),
	(24, 100024, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":43,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:06:17.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:10:11', '2024-07-14 18:10:11', NULL, '', '[]', 'discount_on_product', 1, 0),
	(25, 100025, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":42,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:10:11.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:10:16', '2024-07-14 18:10:16', NULL, '', '[]', 'discount_on_product', 1, 0),
	(26, 100026, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":41,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:10:16.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:10:36', '2024-07-14 18:10:36', NULL, '', '[]', 'discount_on_product', 1, 0),
	(27, 100027, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":40,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:10:36.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:10:39', '2024-07-14 18:10:39', NULL, '', '[]', 'discount_on_product', 1, 0),
	(28, 100028, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":39,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:10:39.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:11:56', '2024-07-14 18:11:56', NULL, '', '[]', 'discount_on_product', 1, 0),
	(29, 100029, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":38,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:11:56.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:12:02', '2024-07-14 18:12:02', NULL, '', '[]', 'discount_on_product', 1, 0),
	(30, 100030, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"yyyyyyyyy","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":37,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:12:02.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 1, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-14 18:12:20', '2024-07-14 18:12:20', NULL, '', '[]', 'discount_on_product', 1, 0),
	(31, 100031, 2, 1, NULL, '{"id":2,"added_by":"admin","user_id":1,"name":"qqqqqqqqqqq","slug":"yyyyyyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":36,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:12:20.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 2, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-15 21:13:35', '2024-07-15 21:13:35', NULL, '', '[]', 'discount_on_product', 1, 0),
	(32, 100031, 8, 1, NULL, '{"id":8,"added_by":"admin","user_id":1,"name":"hhhhhhhhh","slug":"ioxdseLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":36,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:12:20.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 2, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-15 21:13:35', '2024-07-15 21:13:35', NULL, '', '[]', 'discount_on_product', 1, 0),
	(33, 100031, 3, 1, NULL, '{"id":3,"added_by":"admin","user_id":1,"name":"ddddddddd","slug":"ykjyyyy-eLzAKG","product_type":"physical","category_ids":"[{\\"id\\":\\"1\\",\\"position\\":1},{\\"id\\":\\"2\\",\\"position\\":2}]","category_id":1,"sub_category_id":3,"sub_sub_category_id":null,"brand_id":1,"unit":"gms","min_qty":1,"refundable":1,"digital_product_type":null,"digital_file_ready":"","images":"[\\"2024-07-14-6693895070387.webp\\"]","color_image":"[]","thumbnail":"2024-07-14-669389509a060.webp","featured":null,"flash_deal":null,"video_provider":"youtube","video_url":null,"colors":"[]","variant_product":0,"attributes":"null","choice_options":"[]","variation":"[]","published":0,"unit_price":80,"purchase_price":0,"tax":0,"tax_type":"percent","tax_model":"include","discount":0,"discount_type":"flat","current_stock":36,"minimum_order_qty":1,"details":"<p>sdfsdfsdf<br><\\/p>","free_shipping":0,"attachment":null,"created_at":"2024-07-14T08:16:16.000000Z","updated_at":"2024-07-14T15:12:20.000000Z","status":1,"featured_status":1,"meta_title":"pkok[","meta_description":"]ipo[0uo[0i","meta_image":"2024-07-14-669389509e59a.webp","request_status":1,"denied_note":null,"shipping_cost":0,"multiply_qty":0,"temp_shipping_cost":null,"is_shipping_cost_updated":null,"code":"MT4XZC","is_shop_temporary_close":0,"translations":[],"reviews":[]}', 2, 80, 0, 0, 'include', 'pending', 'unpaid', '2024-07-15 21:13:35', '2024-07-15 21:13:35', NULL, '', '[]', 'discount_on_product', 1, 0);

CREATE TABLE IF NOT EXISTS `order_expected_delivery_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expected_delivery_date` date NOT NULL,
  `cause` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `order_status_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cause` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `order_status_histories` (`id`, `order_id`, `user_id`, `user_type`, `status`, `cause`, `created_at`, `updated_at`) VALUES
	(1, 100001, 2, 'customer', 'pending', NULL, '2024-07-14 14:35:03', '2024-07-14 14:35:03'),
	(2, 100002, 2, 'customer', 'pending', NULL, '2024-07-14 14:49:38', '2024-07-14 14:49:38'),
	(3, 100003, 2, 'customer', 'pending', NULL, '2024-07-14 15:00:11', '2024-07-14 15:00:11'),
	(4, 100004, 2, 'customer', 'pending', NULL, '2024-07-14 15:02:56', '2024-07-14 15:02:56'),
	(5, 100005, 2, 'customer', 'pending', NULL, '2024-07-14 15:14:11', '2024-07-14 15:14:11'),
	(6, 100006, 2, 'customer', 'pending', NULL, '2024-07-14 15:42:24', '2024-07-14 15:42:24'),
	(7, 100007, 2, 'customer', 'pending', NULL, '2024-07-14 17:18:27', '2024-07-14 17:18:27'),
	(8, 100008, 2, 'customer', 'pending', NULL, '2024-07-14 17:19:27', '2024-07-14 17:19:27'),
	(9, 100009, 2, 'customer', 'pending', NULL, '2024-07-14 17:23:08', '2024-07-14 17:23:08'),
	(10, 100010, 2, 'customer', 'pending', NULL, '2024-07-14 17:35:05', '2024-07-14 17:35:05'),
	(11, 100011, 2, 'customer', 'pending', NULL, '2024-07-14 17:46:51', '2024-07-14 17:46:51'),
	(12, 100012, 2, 'customer', 'pending', NULL, '2024-07-14 17:47:32', '2024-07-14 17:47:32'),
	(13, 100013, 2, 'customer', 'pending', NULL, '2024-07-14 17:48:28', '2024-07-14 17:48:28'),
	(14, 100014, 2, 'customer', 'pending', NULL, '2024-07-14 17:50:52', '2024-07-14 17:50:52'),
	(15, 100015, 2, 'customer', 'pending', NULL, '2024-07-14 17:53:22', '2024-07-14 17:53:22'),
	(16, 100016, 2, 'customer', 'pending', NULL, '2024-07-14 17:55:18', '2024-07-14 17:55:18'),
	(17, 100017, 2, 'customer', 'pending', NULL, '2024-07-14 17:55:46', '2024-07-14 17:55:46'),
	(18, 100018, 2, 'customer', 'pending', NULL, '2024-07-14 18:02:11', '2024-07-14 18:02:11'),
	(19, 100019, 2, 'customer', 'pending', NULL, '2024-07-14 18:02:35', '2024-07-14 18:02:35'),
	(20, 100020, 2, 'customer', 'pending', NULL, '2024-07-14 18:03:44', '2024-07-14 18:03:44'),
	(21, 100021, 2, 'customer', 'pending', NULL, '2024-07-14 18:04:54', '2024-07-14 18:04:54'),
	(22, 100022, 2, 'customer', 'pending', NULL, '2024-07-14 18:05:12', '2024-07-14 18:05:12'),
	(23, 100023, 2, 'customer', 'pending', NULL, '2024-07-14 18:06:17', '2024-07-14 18:06:17'),
	(24, 100024, 2, 'customer', 'pending', NULL, '2024-07-14 18:10:11', '2024-07-14 18:10:11'),
	(25, 100025, 2, 'customer', 'pending', NULL, '2024-07-14 18:10:16', '2024-07-14 18:10:16'),
	(26, 100026, 2, 'customer', 'pending', NULL, '2024-07-14 18:10:36', '2024-07-14 18:10:36'),
	(27, 100027, 2, 'customer', 'pending', NULL, '2024-07-14 18:10:39', '2024-07-14 18:10:39'),
	(28, 100028, 2, 'customer', 'pending', NULL, '2024-07-14 18:11:56', '2024-07-14 18:11:56'),
	(29, 100029, 2, 'customer', 'pending', NULL, '2024-07-14 18:12:02', '2024-07-14 18:12:02'),
	(30, 100030, 2, 'customer', 'pending', NULL, '2024-07-14 18:12:20', '2024-07-14 18:12:20'),
	(31, 100031, 2, 'customer', 'pending', NULL, '2024-07-15 21:13:35', '2024-07-15 21:13:35');

CREATE TABLE IF NOT EXISTS `order_transactions` (
  `seller_id` bigint NOT NULL,
  `order_id` bigint NOT NULL,
  `order_amount` decimal(50,2) NOT NULL DEFAULT '0.00',
  `seller_amount` decimal(50,2) NOT NULL DEFAULT '0.00',
  `admin_commission` decimal(50,2) NOT NULL DEFAULT '0.00',
  `received_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_charge` decimal(50,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(50,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `seller_is` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `password_resets` (
  `identity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp_hit_count` tinyint NOT NULL DEFAULT '0',
  `is_temp_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `temp_block_time` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'customer',
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `password_resets_email_index` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `payment_requests` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_amount` decimal(24,2) NOT NULL DEFAULT '0.00',
  `gateway_callback_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `success_hook` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failure_hook` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payer_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `external_redirect_link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `attribute_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `paytabs_invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_code` int unsigned NOT NULL,
  `pt_invoice_id` int unsigned DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `currency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` int unsigned DEFAULT NULL,
  `card_brand` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_first_six_digits` int unsigned DEFAULT NULL,
  `card_last_four_digits` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `phone_or_email_verifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone_or_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_hit_count` tinyint NOT NULL DEFAULT '0',
  `is_temp_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `temp_block_time` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `phone_or_email_verifications` (`id`, `phone_or_email`, `token`, `otp_hit_count`, `is_temp_blocked`, `temp_block_time`, `expires_at`, `created_at`, `updated_at`) VALUES
	(1, 'abdotaher@gmail.com', '2942', 0, 0, NULL, NULL, '2024-07-14 11:17:10', '2024-07-14 11:17:10');

CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `added_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'physical',
  `category_ids` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_category_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_sub_category_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` bigint DEFAULT NULL,
  `unit` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_qty` int NOT NULL DEFAULT '1',
  `refundable` tinyint(1) NOT NULL DEFAULT '1',
  `digital_product_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `digital_file_ready` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `color_image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flash_deal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_provider` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colors` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variant_product` tinyint(1) NOT NULL DEFAULT '0',
  `attributes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `choice_options` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `variation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `purchase_price` double NOT NULL DEFAULT '0',
  `tax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00',
  `tax_type` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_model` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'exclude',
  `discount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00',
  `discount_type` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_stock` int DEFAULT NULL,
  `minimum_order_qty` int NOT NULL DEFAULT '1',
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `free_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `attachment` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `featured_status` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_status` tinyint(1) NOT NULL DEFAULT '0',
  `denied_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `shipping_cost` double(8,2) DEFAULT NULL,
  `multiply_qty` tinyint(1) DEFAULT NULL,
  `temp_shipping_cost` double(8,2) DEFAULT NULL,
  `is_shipping_cost_updated` tinyint(1) DEFAULT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `products` (`id`, `added_by`, `user_id`, `name`, `slug`, `product_type`, `category_ids`, `category_id`, `sub_category_id`, `sub_sub_category_id`, `brand_id`, `unit`, `min_qty`, `refundable`, `digital_product_type`, `digital_file_ready`, `images`, `color_image`, `thumbnail`, `featured`, `flash_deal`, `video_provider`, `video_url`, `colors`, `variant_product`, `attributes`, `choice_options`, `variation`, `published`, `unit_price`, `purchase_price`, `tax`, `tax_type`, `tax_model`, `discount`, `discount_type`, `current_stock`, `minimum_order_qty`, `details`, `free_shipping`, `attachment`, `created_at`, `updated_at`, `status`, `featured_status`, `meta_title`, `meta_description`, `meta_image`, `request_status`, `denied_note`, `shipping_cost`, `multiply_qty`, `temp_shipping_cost`, `is_shipping_cost_updated`, `code`) VALUES
	(1, 'admin', 1, 'assaasas', 'assaasas-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '2', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 47, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-14 17:19:27', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(2, 'admin', 1, 'qqqqqqqqqqq', 'yyyyyyyyy-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 34, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-15 21:13:35', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(3, 'admin', 1, 'ddddddddd', 'ykjyyyy-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 34, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-15 21:13:35', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(4, 'admin', 1, 'ccccccc', 'yjliooyyyyy-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 36, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-14 18:12:20', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(5, 'admin', 1, 'vvvvvvvv', ';o;yyyy-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 36, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-14 18:12:20', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(6, 'admin', 1, 'rrrrrrrrr', ';uyhyeLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 36, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-14 18:12:20', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(7, 'admin', 1, 'ttttttttt', 'yoytyyyyyy-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 36, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-14 18:12:20', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(8, 'admin', 1, 'hhhhhhhhh', 'ioxdseLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '3', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 34, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-15 21:13:35', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC'),
	(9, 'admin', 1, 'iiiiiiiii', 'iiiiiiddiii-eLzAKG', 'physical', '[{"id":"1","position":1},{"id":"2","position":2}]', '1', '2', NULL, 1, 'gms', 1, 1, NULL, '', '["2024-07-14-6693895070387.webp"]', '[]', '2024-07-14-669389509a060.webp', NULL, NULL, 'youtube', NULL, '[]', 0, 'null', '[]', '[]', 0, 80, 0, '0', 'percent', 'include', '0', 'flat', 52, 1, '<p>sdfsdfsdf<br></p>', 0, NULL, '2024-07-14 11:16:16', '2024-07-14 17:23:08', 1, 1, 'pkok[', ']ipo[0uo[0i', '2024-07-14-669389509e59a.webp', 1, NULL, 0.00, 0, NULL, NULL, 'MT4XZC');

CREATE TABLE IF NOT EXISTS `product_compares` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL COMMENT 'customer_id',
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `product_stocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `variant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `qty` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `product_tag` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `product_tag` (`id`, `product_id`, `tag_id`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, NULL, NULL),
	(2, 1, 2, NULL, NULL);

CREATE TABLE IF NOT EXISTS `refund_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_details_id` bigint unsigned NOT NULL,
  `customer_id` bigint unsigned NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved_count` tinyint NOT NULL DEFAULT '0',
  `denied_count` tinyint NOT NULL DEFAULT '0',
  `amount` double(8,2) NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `refund_reason` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `approved_note` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rejected_note` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payment_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `change_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `refund_statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `refund_request_id` bigint unsigned DEFAULT NULL,
  `change_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_by_id` bigint unsigned DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `refund_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned DEFAULT NULL,
  `payment_for` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_id` bigint unsigned DEFAULT NULL,
  `payment_receiver_id` bigint unsigned DEFAULT NULL,
  `paid_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_to` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `transaction_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_details_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `refund_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `customer_id` bigint NOT NULL,
  `delivery_man_id` bigint DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  `comment` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachment` json DEFAULT NULL,
  `rating` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '1',
  `is_saved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `search_functions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visible_for` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `search_functions` (`id`, `key`, `url`, `visible_for`, `created_at`, `updated_at`) VALUES
	(1, 'Dashboard', 'admin/dashboard', 'admin', NULL, NULL),
	(2, 'Order All', 'admin/orders/list/all', 'admin', NULL, NULL),
	(3, 'Order Pending', 'admin/orders/list/pending', 'admin', NULL, NULL),
	(4, 'Order Processed', 'admin/orders/list/processed', 'admin', NULL, NULL),
	(5, 'Order Delivered', 'admin/orders/list/delivered', 'admin', NULL, NULL),
	(6, 'Order Returned', 'admin/orders/list/returned', 'admin', NULL, NULL),
	(7, 'Order Failed', 'admin/orders/list/failed', 'admin', NULL, NULL),
	(8, 'Brand Add', 'admin/brand/add-new', 'admin', NULL, NULL),
	(9, 'Brand List', 'admin/brand/list', 'admin', NULL, NULL),
	(10, 'Banner', 'admin/banner/list', 'admin', NULL, NULL),
	(11, 'Category', 'admin/category/view', 'admin', NULL, NULL),
	(12, 'Sub Category', 'admin/category/sub-category/view', 'admin', NULL, NULL),
	(13, 'Sub sub category', 'admin/category/sub-sub-category/view', 'admin', NULL, NULL),
	(14, 'Attribute', 'admin/attribute/view', 'admin', NULL, NULL),
	(15, 'Product', 'admin/product/list', 'admin', NULL, NULL),
	(16, 'Promotion', 'admin/coupon/add-new', 'admin', NULL, NULL),
	(17, 'Custom Role', 'admin/custom-role/create', 'admin', NULL, NULL),
	(18, 'Employee', 'admin/employee/add-new', 'admin', NULL, NULL),
	(19, 'Seller', 'admin/sellers/seller-list', 'admin', NULL, NULL),
	(20, 'Contacts', 'admin/contact/list', 'admin', NULL, NULL),
	(21, 'Flash Deal', 'admin/deal/flash', 'admin', NULL, NULL),
	(22, 'Deal of the day', 'admin/deal/day', 'admin', NULL, NULL),
	(23, 'Language', 'admin/business-settings/language', 'admin', NULL, NULL),
	(24, 'Mail', 'admin/business-settings/mail', 'admin', NULL, NULL),
	(25, 'Shipping method', 'admin/business-settings/shipping-method/add', 'admin', NULL, NULL),
	(26, 'Currency', 'admin/currency/view', 'admin', NULL, NULL),
	(27, 'Payment method', 'admin/business-settings/payment-method', 'admin', NULL, NULL),
	(28, 'SMS Gateway', 'admin/business-settings/sms-gateway', 'admin', NULL, NULL),
	(29, 'Support Ticket', 'admin/support-ticket/view', 'admin', NULL, NULL),
	(30, 'FAQ', 'admin/helpTopic/list', 'admin', NULL, NULL),
	(31, 'About Us', 'admin/business-settings/about-us', 'admin', NULL, NULL),
	(32, 'Terms and Conditions', 'admin/business-settings/terms-condition', 'admin', NULL, NULL),
	(33, 'Web Config', 'admin/business-settings/web-config', 'admin', NULL, NULL);

CREATE TABLE IF NOT EXISTS `sellers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `f_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def.png',
  `email` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holder_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sales_commission_percentage` double(8,2) DEFAULT NULL,
  `gst` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cm_firebase_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pos_status` tinyint(1) NOT NULL DEFAULT '0',
  `minimum_order_amount` double(8,2) NOT NULL DEFAULT '0.00',
  `free_delivery_status` int NOT NULL DEFAULT '0',
  `free_delivery_over_amount` double(8,2) NOT NULL DEFAULT '0.00',
  `app_language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sellers_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `seller_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint DEFAULT NULL,
  `total_earning` double NOT NULL DEFAULT '0',
  `withdrawn` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `commission_given` double(8,2) NOT NULL DEFAULT '0.00',
  `pending_withdraw` double(8,2) NOT NULL DEFAULT '0.00',
  `delivery_charge_earned` double(8,2) NOT NULL DEFAULT '0.00',
  `collected_cash` double(8,2) NOT NULL DEFAULT '0.00',
  `total_tax_collected` double(8,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `seller_wallet_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `payment` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `shipping_addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_guest` tinyint NOT NULL DEFAULT '0',
  `contact_person_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'home',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_billing` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `shipping_addresses` (`id`, `customer_id`, `is_guest`, `contact_person_name`, `email`, `address_type`, `address`, `city`, `zip`, `phone`, `created_at`, `updated_at`, `state`, `country`, `latitude`, `longitude`, `is_billing`) VALUES
	(1, '2', 0, 'Tanner Cole', NULL, 'others', 'Dolorem est modi num', 'Sed ut culpa labore ', '24675', '+117981199233', NULL, '2024-07-14 18:01:29', NULL, 'Afghanistan', '0', '0', 0),
	(2, '2', 0, 'dfsfds', NULL, 'home', 'fgjh', 'nmjhkh', '534', '+201008275881', NULL, NULL, NULL, 'Anguilla', '-33.87760809349691', '151.19947283848236', 1),
	(3, '0', 0, 'Hyacinth Bray', NULL, 'others', 'Voluptatem et aperia', 'Labore blanditiis la', '54573', '+114077951202', NULL, NULL, NULL, 'Germany', '0', '0', 0),
	(4, '0', 0, 'Ulla Madden', NULL, 'home', 'Distinctio Molestia', 'Irure ratione ut vel', '49512', '+116521991894', NULL, NULL, NULL, 'Afghanistan', '0', '0', 1),
	(5, '0', 0, 'Ashely Leon', NULL, 'permanent', 'Aut quia enim repreh', 'Aut saepe quia atque', '23707', '+117175538576', NULL, NULL, NULL, 'Tokelau', '0', '0', 0),
	(6, '0', 0, 'Raymond Lane', NULL, 'others', 'Officia sit pariatu', 'Ipsum voluptatem At', '29306', '+112234115554', NULL, NULL, NULL, 'Palau', '0', '0', 0),
	(7, '0', 0, 'Daria Leonard', NULL, 'others', 'Officiis ipsum esse', 'Sit debitis molestia', '44320', '+119321559263', NULL, NULL, NULL, 'Palau', '0', '0', 0),
	(8, '0', 0, 'Daria Leonard', NULL, 'others', 'Officiis ipsum esse', 'Sit debitis molestia', '44320', '+119321559263', NULL, NULL, NULL, 'Afghanistan', '0', '0', 1),
	(9, '0', 0, 'Daria Leonard', NULL, 'others', 'Officiis ipsum esse', 'Sit debitis molestia', '44320', '+119321559263', NULL, NULL, NULL, 'Palau', '0', '0', 0),
	(10, '0', 0, 'Daria Leonard', NULL, 'others', 'Officiis ipsum esse', 'Sit debitis molestia', '44320', '+119321559263', NULL, NULL, NULL, 'Afghanistan', '0', '0', 1),
	(11, '0', 0, 'Daria Leonard', NULL, 'others', 'Officiis ipsum esse', 'Sit debitis molestia', '44320', '+119321559263', NULL, NULL, NULL, 'Palau', '0', '0', 0),
	(12, '0', 0, 'Daria Leonard', NULL, 'others', 'Officiis ipsum esse', 'Sit debitis molestia', '44320', '+119321559263', NULL, NULL, NULL, 'Afghanistan', '0', '0', 1),
	(13, '0', 0, 'Austin Waller', NULL, 'permanent', 'Dolores ut totam obc', 'Voluptas illo rerum ', '12251', '+117145714981', NULL, NULL, NULL, 'Palau', '0', '0', 0),
	(14, '0', 0, 'Honorato Blake', NULL, 'permanent', 'Eos sit laboris sin', 'Doloribus excepteur ', '45478', '+111038891674', NULL, NULL, NULL, 'Afghanistan', '0', '0', 1),
	(15, '0', 0, 'Tanner Colefdgfd', NULL, 'others', 'Dolorem est modi num', 'Sed ut culpa labore ', '24675', '+117981199233', NULL, NULL, NULL, 'Afghanistan', '0', '0', 0),
	(16, '0', 0, 'Tanner Cole', NULL, 'others', 'Dolorem est modi num', 'Sed ut culpa labore ', '24675', '+117981199233', NULL, NULL, NULL, 'Afghanistan', '0', '0', 1);

CREATE TABLE IF NOT EXISTS `shipping_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` bigint DEFAULT NULL,
  `creator_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost` decimal(8,2) NOT NULL DEFAULT '0.00',
  `duration` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `shipping_methods` (`id`, `creator_id`, `creator_type`, `title`, `cost`, `duration`, `status`, `created_at`, `updated_at`) VALUES
	(2, 1, 'admin', 'Company Vehicle', 5.00, '2 Week', 1, '2021-05-25 20:57:04', '2021-05-25 20:57:04');

CREATE TABLE IF NOT EXISTS `shipping_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint unsigned DEFAULT NULL,
  `shipping_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `shipping_types` (`id`, `seller_id`, `shipping_type`, `created_at`, `updated_at`) VALUES
	(1, 0, 'product_wise', '2024-07-07 11:00:25', '2024-07-07 08:05:56');

CREATE TABLE IF NOT EXISTS `shops` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def.png',
  `bottom_banner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer_banner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacation_start_date` date DEFAULT NULL,
  `vacation_end_date` date DEFAULT NULL,
  `vacation_note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacation_status` tinyint NOT NULL DEFAULT '0',
  `temporary_close` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `banner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `shop_followers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int NOT NULL,
  `user_id` int NOT NULL COMMENT 'Customer ID',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `social_medias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_status` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `social_medias` (`id`, `name`, `link`, `icon`, `active_status`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'twitter', 'https://www.w3schools.com/howto/howto_css_table_responsive.asp', 'fa fa-twitter', 1, 1, '2020-12-31 21:18:03', '2020-12-31 21:18:25'),
	(2, 'linkedin', 'https://dev.6amtech.com/', 'fa fa-linkedin', 1, 1, '2021-02-27 16:23:01', '2021-02-27 16:23:05'),
	(3, 'google-plus', 'https://dev.6amtech.com/', 'fa fa-google-plus-square', 1, 1, '2021-02-27 16:23:30', '2021-02-27 16:23:33'),
	(4, 'pinterest', 'https://dev.6amtech.com/', 'fa fa-pinterest', 1, 1, '2021-02-27 16:24:14', '2021-02-27 16:24:26'),
	(5, 'instagram', 'https://dev.6amtech.com/', 'fa fa-instagram', 1, 1, '2021-02-27 16:24:36', '2021-02-27 16:24:41'),
	(6, 'facebook', 'facebook.com', 'fa fa-facebook', 1, 1, '2021-02-27 19:19:42', '2021-06-11 17:41:59');

CREATE TABLE IF NOT EXISTS `soft_credentials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint DEFAULT NULL,
  `subject` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'low',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `reply` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `support_ticket_convs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `support_ticket_id` bigint DEFAULT NULL,
  `admin_id` bigint DEFAULT NULL,
  `customer_message` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `admin_message` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `visit_count` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `tags` (`id`, `tag`, `visit_count`, `created_at`, `updated_at`) VALUES
	(1, 'oioo', 0, '2024-07-14 11:16:16', '2024-07-14 11:16:16'),
	(2, 'oioi', 0, '2024-07-14 11:16:16', '2024-07-14 11:16:16');

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL,
  `payment_for` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_id` bigint DEFAULT NULL,
  `payment_receiver_id` bigint DEFAULT NULL,
  `paid_by` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_to` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `amount` double(8,2) NOT NULL DEFAULT '0.00',
  `transaction_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_details_id` bigint unsigned DEFAULT NULL,
  UNIQUE KEY `transactions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `translations` (
  `translationable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `translationable_id` bigint unsigned NOT NULL,
  `locale` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `translations_translationable_id_index` (`translationable_id`),
  KEY `translations_locale_index` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `translations` (`translationable_type`, `translationable_id`, `locale`, `key`, `value`, `id`) VALUES
	('App\\Models\\Category', 1, 'sa', 'name', 'الأدوية', 1),
	('App\\Models\\Category', 2, 'sa', 'name', 'جميع الادويه', 2),
	('App\\Models\\Category', 3, 'sa', 'name', 'نواقص السوق', 3),
	('App\\Models\\Category', 4, 'sa', 'name', 'عروض الأدوية', 4),
	('App\\Models\\Category', 5, 'sa', 'name', 'جديد السوق', 5),
	('App\\Models\\Category', 6, 'sa', 'name', 'مستحضرات التجميل', 6),
	('App\\Models\\Category', 7, 'sa', 'name', 'مستحضرات تجميل', 7),
	('App\\Models\\Category', 8, 'sa', 'name', 'شركات', 8),
	('App\\Models\\Category', 9, 'sa', 'name', 'جديد السوق', 9),
	('App\\Models\\Category', 10, 'sa', 'name', 'ورقيات  اطفال', 10),
	('App\\Models\\Category', 11, 'sa', 'name', 'ورقيات نساء', 11),
	('App\\Models\\Category', 12, 'sa', 'name', 'مستلزمات طبيه', 12);

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `f_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def.png',
  `email` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `street_address` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `house_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apartment_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cm_firebase_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `payment_card_last_four` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_card_brand` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_card_fawry_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `login_medium` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_phone_verified` tinyint(1) NOT NULL DEFAULT '0',
  `temporary_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `wallet_balance` double(8,2) DEFAULT NULL,
  `loyalty_point` double(8,2) DEFAULT NULL,
  `login_hit_count` tinyint NOT NULL DEFAULT '0',
  `is_temp_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `temp_block_time` timestamp NULL DEFAULT NULL,
  `referral_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referred_by` int DEFAULT NULL,
  `app_language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `slice_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `users` (`id`, `name`, `f_name`, `l_name`, `phone`, `image`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `street_address`, `country`, `city`, `zip`, `house_no`, `apartment_no`, `cm_firebase_token`, `is_active`, `payment_card_last_four`, `payment_card_brand`, `payment_card_fawry_token`, `login_medium`, `social_id`, `is_phone_verified`, `temporary_token`, `is_email_verified`, `wallet_balance`, `loyalty_point`, `login_hit_count`, `is_temp_blocked`, `temp_block_time`, `referral_code`, `referred_by`, `app_language`, `slice_id`) VALUES
	(0, 'walking customer', 'walking', 'customer', '000000000000', 'def.png', 'walking@customer.com', NULL, '', NULL, NULL, '2022-02-03 03:46:01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, 'en', NULL),
	(2, 'abdo taher', 'abdo', 'taher', '+201008275881', 'def.png', 'abdotaher@gmail.com', NULL, '$2y$10$YvLo6Q1JL7FGmMFVuNnHsemGzlKXYu0EvPHYbVXFt4rRACU2kkTfe', 'sW8kv5VIcchSuupjw3iXXbdDZXo34VwdKhciHFSaCsDBhVpB1hMaWLfi2hiO', '2024-07-14 11:17:10', '2024-07-15 21:26:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0, NULL, 'OK0URVS68UFPOVG1ZQ8B', NULL, 'en', 4);

CREATE TABLE IF NOT EXISTS `vendor_registration_reasons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `priority` tinyint NOT NULL DEFAULT '1',
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

REPLACE INTO `vendor_registration_reasons` (`id`, `title`, `description`, `priority`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'Millions of Users', 'Access a vast audience with millions of active users ready to buy your products.', 1, 1, NULL, NULL),
	(2, 'Free Marketing', 'Benefit from our extensive, no-cost marketing efforts to boost your visibility and sales.', 2, 1, NULL, NULL),
	(3, 'SEO Friendly', 'Enjoy enhanced search visibility with our SEO-friendly platform, driving more traffic to your listings.', 3, 1, NULL, NULL),
	(4, '24/7 Support', 'Get round-the-clock support from our dedicated team to resolve any issues and assist you anytime.', 4, 1, NULL, NULL),
	(5, 'Easy Onboarding', 'Start selling quickly with our user-friendly onboarding process designed to get you up and running fast.', 5, 1, NULL, NULL);

CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `transaction_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` decimal(24,3) NOT NULL DEFAULT '0.000',
  `debit` decimal(24,3) NOT NULL DEFAULT '0.000',
  `admin_bonus` decimal(24,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(24,3) NOT NULL DEFAULT '0.000',
  `transaction_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `wishlists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `withdrawal_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `method_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `withdraw_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint DEFAULT NULL,
  `delivery_man_id` bigint DEFAULT NULL,
  `admin_id` bigint DEFAULT NULL,
  `amount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00',
  `withdrawal_method_id` bigint unsigned DEFAULT NULL,
  `withdrawal_method_fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `transaction_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
